<?php get_header(); ?>

<div class="cat-loop container">

	<div class="cat-title">
		<h1><?php the_archive_title();?></h1>
	</div>

	<div id="posts-box">
		<?php
		$queried 	= get_queried_object();
		$authorid 	= $queried->ID;

		$args = array(
			'post_type'			=> 'post', 
            'posts_per_page'	=> 6,
            'author'            => $authorid
		);
        $query = new WP_Query( $args );

        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
				
				// item data
				$pid 			= get_the_ID();
				$plink 			= get_permalink();
				$title 			= get_the_title();
				$date 			= get_the_date( 'l, F j, Y', $pid );
				$excerpt 		= content_to_excerpt( get_the_content(), 120 );

				// THUMB SETTINGS
				$thumb['id']	= get_post_thumbnail_id($pid);
				$thumb['url']	= get_the_post_thumbnail_url($pid, 'full');
				$thumb['alt']	= get_post_meta($thumb['id'], '_wp_attachment_image_alt', true);


				// IF NO THUMB WAS SET
				if($thumb['url'] == '') {
					$thumb['url'] = of_get_option(THEME_PREF.'default_post_thumb');
					$thumb['alt'] = __('Post Thumb', THEME_NAME);
				}


				echo '
				<div class="cat-post-item">
					<div class="row">
						<div class="col-md-6 col-sm-6 col-xs-12">
							'.(is_mobile() ? '<div class="mobiledate">'.$date.'</div>' : '').'
							<a href="'.$plink.'"> <img src="'.$thumb['url'].'" alt="'.$thumb['alt'].'" class="img-responsive"> </a>
						</div>
						<div class="col-md-6 col-sm-6 col-xs-12">
							<h3 class="item-title"><a href="'.$plink.'">'.$title.'</a></h3>
							'.(!is_mobile() ? '<div class="date">'.$date.'</div>' : '').'
							<div class="excerpt">'.$excerpt.'</div>
							<div class="rmore"><a href="'.$plink.'" class="btn btn-default">'.__('Read More', THEME_NAME).'</a></div>
						</div>
					</div>
				</div>
				';


			}
		}
		?>
	</div>

	<div class="cat-loadmore-box">
		<button id="postsLoadMore" data-count="6" data-ccat="" data-tag="" data-author="<?php echo $authorid; ?>" class="btn btn-blue"> <img src="<?php echo IMG_URL; ?>/loading-btn.svg" alt="loading" class="loading"> <?php _e('Load More', THEME_NAME); ?></button>
		<div class="nomoreposts"><?php echo of_get_option(THEME_PREF.'nomore_posts_blog'); ?></div>
	</div>
</div>


<?php get_footer(); ?>