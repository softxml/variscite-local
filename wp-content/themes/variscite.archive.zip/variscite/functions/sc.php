<?php
/*********************************************
** CURRENT YEAR
*********************************************/
add_shortcode('cyear', 'sc_cyear');
function sc_cyear($atts, $content = null) {

	// return result
    return date('Y');
}




/*************************************************
** DYNMIC LIST
*************************************************/
add_shortcode('list', 'sc_dynamic_list');
function sc_dynamic_list($atts, $content = null) {

	extract(shortcode_atts(array(
	"design"    => '',
	"classes"   => '',
	"id"        => ''
	), $atts));


	// wrap inner LI with span
	$content = str_replace('<li>', '<li><span>', $content);
	$content = str_replace('</li>', '</span></li>', $content);


	// return result
    return '
    <div id="'.$id.'" class="clist list-'.$design.' '.$classes.'">
        '.$content.'
    </div>
    ';
}



/*************************************************
** EASY ICONS
*************************************************/
add_shortcode('icon', 'sc_easy_icon');
function sc_easy_icon($atts, $content = null) {

	extract(shortcode_atts(array(
	"name"    	=> '',
	"classes"   => ''
	), $atts));


	// return result
    return '<img src="'.IMG_URL.'/icons/'.$name.'.png" alt="'.$name.'" '.($classes ? 'class="'.$classes.'"' : '').' >';
}



/*************************************************
** EASY TOOLTIP
*************************************************/
add_shortcode('tooltip', 'sc_easy_tooltip');
function sc_easy_tooltip($atts, $content = null) {

	extract(shortcode_atts(array(
	"tip"    	=> '',
	"classes"   => ''
	), $atts));


	// return result
    return '<span class="slow-tip" data-toggle="tooltip" title="'.$content.'">'.content_to_excerpt($content, 25).'</span>';
}



/*************************************************
** EASY TOOLTIP
*************************************************/
add_shortcode('diagram', 'sc_diagram');
function sc_diagram($atts, $content = null) {

    extract(shortcode_atts(array(
        "tip"     => '',
        "classes"   => ''
    ), $atts));

    $diagram = get_field('vrs_specs_block_diagram', get_the_ID());
    // return result

    if( have_rows('vrs_specs_block_multiple_diagrams', get_the_ID()) ): $i = 0;
        $diagram_tabs = '';
        $diagram_tabs_content = '';
        while( have_rows('vrs_specs_block_multiple_diagrams', get_the_ID()) ): the_row(); $i++;
            $image = get_sub_field('vrs_specs_block_multiple_diagrams');
            $caption = get_sub_field('vrs_specs_block_multiple_diagrams_caption');
            $diagram_tabs .= '<div class="vrs-diagram-tab-caption" data-tab="diagram-tab-'.$i.'">'.$caption.'</div><div class="vrs-diagram-image-wrap-mobile"><div data-name="diagram-tab-'.$i.'" class="vrs-diagram-tab-image"><img src="'.$image['url'].'" alt="'.$image['alt'].' '.__('Diagram', THEME_NAME).'"></div></div>';
            $diagram_tabs_content .= '<div id="diagram-tab-'.$i.'" class="vrs-diagram-tab-image"><img src="'.$image['url'].'" alt="'.$image['alt'].' '.__('Diagram', THEME_NAME).'"></div>';
        endwhile;

        return '<div class="vrs-diagrams-wrap"><div class="vrs-diagram-tabs">'.$diagram_tabs.'</div><div class="vrs-diagram-image-wrap-desktop">'.$diagram_tabs_content.'</div></div>';

    elseif($diagram) :
        return '<img src="'.$diagram['url'].'" alt="'.$diagram['alt'].' '.__('Diagram', THEME_NAME).'">';
    endif;
}


/*************************************************
** EASY BUTTON
*************************************************/
add_shortcode('button', 'sc_button');
function sc_button($atts, $content = null) {

	extract(shortcode_atts(array(
	"type"    	=> '',
	"url"    	=> '',
	"size"    	=> '',
	"classes"   => ''
	), $atts));

	return '<a href="'.$url.'" class="btn btn-'.$type.' '.$size.' '.$classes.'">'.$content.'</a>';
}




/*********************************************
** EASY TAB LINK
*********************************************/
add_shortcode('tab', 'ez_tablink');
function ez_tablink($atts, $content = null) {

	extract(shortcode_atts(array(
		"name"    	=> '',
		"classes"   => ''
	), $atts));

	return '<a href="#'.str2id($name).'" class="tab-link '.$classes.'">'.$content.'</a>';
}


/*********************************************
** EASY LIGHT TEXT WEIGHT WRAP
*********************************************/
add_shortcode('light', 'ez_lightxt');
function ez_lightxt($atts, $content = null) {
	return '<span class="light">'.$content.'</span>';
}
?>