<?php
function sg_theme_js(){
	
	wp_enqueue_style('bootstrapcss', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css', array(), '3.3.6', 'all');
	wp_enqueue_style('fontawesome', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css', array());

	if( is_singular('products') || is_singular('specs') ) {
		wp_enqueue_style('bxsliderCss', 'https://cdnjs.cloudflare.com/ajax/libs/bxslider/4.2.12/jquery.bxslider.min.css', array());
	}

    wp_enqueue_style('RobotoFont', 'https://fonts.googleapis.com/css?family=Roboto:300,400,700', array());
	// wp_enqueue_style('maincss', BASE_URL . '/css/main.css?v='.time(), array('bootstrapcss'));
	wp_enqueue_style('maincss', BASE_URL . '/css/main.css', array('bootstrapcss'));
	
	wp_enqueue_style('custom_css', BASE_URL . '/css/custom.css', array('bootstrapcss'));

	// COMPARE PAGE CSS
	if( is_page_template('custom-pages/page-compare.php') ) {
		wp_enqueue_style('datatablesCss', 'https://cdn.datatables.net/v/dt/dt-1.10.16/fc-3.2.4/fh-3.1.3/datatables.min.css', array());
	}




	// FILTER PAGE CSS
	$cat = get_queried_object();
	if ($cat->term_id == 43 || $cat->term_id == 65 || $cat->term_id == 99) {
		if(is_user_logged_in()) {
			wp_enqueue_style('iziToastCss', BASE_URL . '/js/iziToast/iziToast.min.css', array());
		}
	}

    wp_enqueue_script('js-cookie', BASE_URL.'/js/js.cookie.min.js', array(), false, false);

	// FILTER PAGE
	if ($cat->term_id == 43 || $cat->term_id == 65 || $cat->term_id == 99) {
		wp_enqueue_script('nouislider', BASE_URL.'/js/nouislider.min.js', array(), false, false);

		if(is_user_logged_in()) {
			wp_enqueue_script('iziToastJs', BASE_URL.'/js/iziToast/iziToast.min.js', array(), false, false);
		}
	}


	// MOBILE: SINGLE SPECS PAGE // HOME MOBILE
	if( is_mobile() ) {
		if( is_singular('specs') || is_home() || is_front_page() ) {
			wp_enqueue_script('touchSwipe', 'https://cdnjs.cloudflare.com/ajax/libs/jquery.touchswipe/1.6.4/jquery.touchSwipe.min.js', array('jquery'), false, true);
		}
	}

	wp_enqueue_script('bootstrap', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js', array('jquery'), '3.3.6', true);
	// wp_enqueue_script('miscscripts', BASE_URL.'/js/main.min.js?v='.time(), array('jquery'), false, true);
	wp_enqueue_script('miscscripts', BASE_URL.'/js/main.min.js', array('jquery'), false, true);
    wp_enqueue_script('custom-scripts', BASE_URL.'/js/custom-scripts.js', array('jquery'), false, true);

	if( is_singular('products') || is_singular('specs') ) {
		wp_enqueue_script('bxsliderJs', 'https://cdnjs.cloudflare.com/ajax/libs/bxslider/4.2.12/jquery.bxslider.min.js', array('jquery'), false, true);
        wp_enqueue_script('diagram-tabs', BASE_URL.'/js/diagram-tabs.js', array('jquery'), false, true);
	}
	

	// COMPARE PAGE JS
	if( is_page_template('custom-pages/page-compare.php') ) {
		wp_enqueue_script('xlsx-core', BASE_URL.'/js/xlsx.core.min.js', array('jquery'), false, true);
		wp_enqueue_script('fileSaver', BASE_URL.'/js/FileSaver.min.js', array('jquery'), false, true);
		wp_enqueue_script('tableexport', BASE_URL.'/js/tableexport.min.js', array('jquery', 'fileSaver'), false, true);
		// wp_enqueue_script('datatablesJs', 'https://cdn.datatables.net/v/dt/dt-1.10.16/fc-3.2.4/fh-3.1.3/datatables.min.js', array('jquery'), false, true);
	}


	// MOBILE: TOUCH SWIPE SUPPORT FOR COMPARE PAGE
	if( is_mobile() && is_page_template('custom-pages/page-compare.php') || is_page_template('custom-pages/page-compare-new.php') ) {
		wp_enqueue_script('touchSwipe', BASE_URL.'/js/jquery.touchSwipe.min.js', array('jquery'), false, true);
	}


	// FILTER PAGE JS
	global $wp;
	if (strpos(home_url( $wp->request ), 'products/system-on-module-som') !== false) {
		//if ( get_page_by_title( 'System on module', '', 'page' ) ) {
			wp_enqueue_script( 'filterFuncJs', BASE_URL . '/js/filter-functions.js', array( 'jquery' ), false, true );
		//}
	}
	
	// TAXONOMY PRODUCTS FILTERS
	$term                   = get_queried_object();
	if(get_field('prod_specs_enable_filters', $term)){
//		wp_enqueue_script('custom_js', BASE_URL.'/js/custom.js', array('jquery'), false, true);
		wp_enqueue_script('specs_filters_ajax', BASE_URL.'/ajax/specs-filters-ajax.js', array('jquery'), false, true);
	}
	
    wp_enqueue_script('langOpen', BASE_URL.'/js/lang-open.js', array('jquery'), false, true);
	
}
add_action('wp_enqueue_scripts', 'sg_theme_js');
?>