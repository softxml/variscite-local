<?php
// function sgx_admin_ordercpt_bydate($wp_query) {
// 	if (is_admin()) {
		
// 		$post_type	= $wp_query->query['post_type'];	// Get the post type from the query
// 		$cpts_array	= array(
// 			'specs',
// 			'leads',
// 			'pdfiles',
// 		);
		
// 		if (in_array($post_type, $cpts_array)) { 
// 			$wp_query->set('orderby', 'date');
// 			$wp_query->set('order', 'DESC');
// 		}
		
// 	}
// }
// add_filter('pre_get_posts', 'sgx_admin_ordercpt_bydate');
?>