<?php
add_action('wp_footer', 'schemaorg_structure_injector');
function schemaorg_structure_injector() {


    // SINGLE POST
    if( is_singular('post') ) {

        $p['id']        = get_the_ID();
        $p['title']     = get_the_title();
        $p['excerpt']   = get_the_excerpt();
        $p['thumb']     = get_the_post_thumbnail_url($p['id'], 'full');
        $p['date']      = get_the_date( 'c', $p['id'] );
        $p['author']    = get_the_author();
        $p['org']       = get_field('optage_company_sname', 'option');
        $p['logo']      = get_field('optage_company_logo', 'option');

        echo '
        <script type="application/ld+json">
        {
            "@context": "http://schema.org",
            "@type": "BlogPosting",
            "mainEntityOfPage": {
                "@type": "WebPage",
                "@id": "https://google.com/article"
            },
            "headline": "'.$p['title'].'",
            "image": [
                "'.$p['thumb'].'"
            ],
            "datePublished": "'.$p['date'].'",
            "dateModified": "'.$p['date'].'",
            "author": {
                "@type": "Person",
                "name": "'.$p['author'].'"
            },
            "publisher": {
                "@type": "Organization",
                "name": "'.$p['org'].'",
                "logo": {
                    "@type": "ImageObject",
                    "url": "'.$p['logo'].'"
                }
            },
            "description": "'.$p['excerpt'].'"
        }
        </script>
        ';

    }

    elseif(is_singular('specs')) {

        $spec['id']       = get_the_ID();
        $spec['category'] = get_the_terms($spec['id'], 'products');

        $som_term_id = get_term_by('slug', 'system-on-module-som', 'products')->term_id;
        $is_som = ($spec['category'][0]->parent == $som_term_id) || ($spec['category'][0]->term_id == $som_term_id);

		$product_thumbs	= get_field('vrs_specs_slider_media', $spec['id']);
        $spec['thumbs'] = '';

		foreach($product_thumbs as $thumb_key => $product_thumb) {
            $spec['thumbs'] .= '"' . $product_thumb['sliderimg'] . '"';

            if($thumb_key + 1 < count($product_thumbs)) {
                $spec['thumbs'] .= ', ' . "\n";
            } else {
                $spec['thumbs'] .= "\n";
            }
        }

        $spec['title']    = get_the_title() . ($is_som ? ' System on Module' : '');
        $spec['desc']	  = strip_tags(get_field('vrs_specs_product_middesc', $spec['id']));
        $spec['sku']      = trim(explode(':', $spec['title'])[0]);
        $spec['url']      = get_permalink($spec['id']);
        $spec['price']    = trim(str_replace(
            array('starting', 'from', ':', 'price', '$'),
            '',
            strtolower(get_field('vrs_specs_price', $spec['id']))
        ));

        if(
            ctype_alnum(str_replace(' ', '', $spec['price'])) ||
            ctype_alpha(str_replace(' ', '', $spec['price']))
        ) {
            $spec['price'] = preg_replace("/[^0-9.]/", "", $spec['price']);
        }

        if(empty($spec['price'])) {
            $spec['price'] = 0;
        }

        echo preg_replace( "/\r|\n|\s+/", " ",'
            <script type="application/ld+json">
            {
                "@context": "https://schema.org/",
                "@type": "Product",
                "name": "' . $spec['title'] . '",
                "image": [
                    ' . $spec['thumbs'] . '
                ],
                "description": "' . $spec['desc'] . '",
                "sku": "' . $spec['sku'] . '",
                "brand": {
                    "@type": "Thing",
                    "name": "Variscite"
              },
            "offers": {
                    "@type": "Offer",
                    "url": "' . $spec['url'] . '",
                    "priceCurrency": "USD",
                    "price": "' . $spec['price'] . '",
                    "itemCondition": "http://schema.org/NewCondition",
                    "availability": "https://schema.org/InStock",
                    "seller": {
                        "@type": "Organization",
                        "name": "Variscite"
                    }
                }
            }
            </script>
        ') . "\n" . "\n";
    }

}
?>