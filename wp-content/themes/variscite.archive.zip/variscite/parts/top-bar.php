<?php
$logo     = get_field('optage_company_logo', 'option');
$logoAlt  = get_field('optage_company_sname', 'option');
$logoTitle  = get_field('optage_logo_title', 'option');

// LOGO TITLE
if($logoTitle) {$logoTitle = 'title="'.$logoTitle.'"';} else {$logoTitle = '';} ?>

<div id="desktopMenuWrap" class="top-menu-box">
	<nav class="navbar" role="navigation">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-2 col-xs-12">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-topmenu">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>

						<a href="/" class="logo"><img src="<?php echo $logo; ?>" alt="<?php echo $logoAlt; ?>" <?php echo $logoTitle; ?> ></a>
					</div>
				</div>
				<div class="col-md-10 col-xs-12">
					<?php wp_nav_menu( array( 'theme_location' => 'topmenu' ) ); ?>
				</div>
			</div>
		</div>
	</nav>
</div>

<div id="mobileMenuWrap">
	<nav class="navbar navbar-default navbar-fixed-bottom" role="navigation">
		<div class="container-fluid">
			
			
			<?php
			wp_nav_menu( array(
					'menu'              => 'topmenumobile',
					'theme_location'    => 'topmenumobile',
					'depth'             => 2,
					'container'         => 'div',
					'container_class'   => 'collapse navbar-collapse',
					'container_id'      => 'bs-topmenumobile',
					'menu_class'        => 'nav navbar-nav',
					'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
					'walker'            => new wp_bootstrap_navwalker())
			);
			?>

			<div class="navbar-header">

				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-topmenumobile">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>

				<a href="https://shop.variscite.com/" class="storelink pull-right" style="padding: 11px 10px; cursor: pointer;"><img src="<?php echo IMG_URL; ?>/cart-icon.png" alt="<?php _e('Store', THEME_NAME); ?>"></a>

                <div class="language-switcher bottom-language-switcher">
                    <?php echo custom_wpml_lang_switcher(); ?>
                </div>

				<a href="<?php echo bloginfo('wpurl'); ?>" class="c1"><img src="<?php echo $logo; ?>" alt="<?php echo $logoAlt; ?>" <?php echo $logoTitle; ?> ></a>
			</div>

		</div>
	</nav>
	<div class="clearfix"></div>
</div>
