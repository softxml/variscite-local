(function($) {
    var fixedCls = '.top-menu-box';
    var oldSSB = $.fn.modal.Constructor.prototype.setScrollbar;
    $.fn.modal.Constructor.prototype.setScrollbar = function () {
        oldSSB.apply(this);
        if (this.bodyIsOverflowing && this.scrollbarWidth)
            $(fixedCls).css('padding-right', this.scrollbarWidth);
    }

    var oldRSB = $.fn.modal.Constructor.prototype.resetScrollbar;
    $.fn.modal.Constructor.prototype.resetScrollbar = function () {
        oldRSB.apply(this);
        $(fixedCls).css('padding-right', '');
    }

    // Header cart cookie
    var products_amount = Cookies.get('variscite_products_count'),
        cart_item_html = '<ul class="cart_menu"><span class="tooltip"></span><li><a href="https://shop.variscite.com">Shop all products</a></li>';

    if(products_amount && products_amount > 0) {

        cart_item_html += '<li><a href="https://shop.variscite.com/cart">Shopping Cart</a></li><li><a href="https://shop.variscite.com/checkout">Checkout</a></li>';

        $('#desktopMenuWrap .mega-store.store a, #mobileMenuWrap .storelink').append('<span class="number-of-items">' + products_amount + '</span>');
    }

    cart_item_html += '</ul>';

    $('#desktopMenuWrap .mega-store.store').append(cart_item_html);

}(jQuery));