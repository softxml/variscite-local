jQuery(function($){
    $('.bottom-language-switcher').on('click', function(){
       $(this).toggleClass('open');
    });
});