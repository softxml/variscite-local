
	<?php
	$footerMargin = get_field('pp_page_nofooter_margin', get_the_id());
	?>

	<footer class=" <?php if($footerMargin[0] == 'on') {echo 'footerNoMargin';} ?> ">
		<div class="container">

			<div class="menus">
				<div class="row">
					<?php if(!is_mobile()) { ?> 
					<div class="col-md-9">
						<div class="col-md-3 col-sm-3"> <?php if ( is_active_sidebar('footersb1') ) { dynamic_sidebar( 'footersb1' ); } ?> </div>
						<div class="col-md-3 hidden-sm"> <?php if ( is_active_sidebar('footersb2') ) { dynamic_sidebar( 'footersb2' ); } ?> </div>
						<div class="col-md-3 hidden-sm"> <?php if ( is_active_sidebar('footersb3') ) { dynamic_sidebar( 'footersb3' ); } ?> </div>
						<div class="col-md-3 col-sm-3"> <?php if ( is_active_sidebar('footersb4') ) { dynamic_sidebar( 'footersb4' ); } ?> </div>
						<?php /* 
						<div class="col-md-3 col-sm-3"> <?php if ( is_active_sidebar('footersb5') ) { dynamic_sidebar( 'footersb5' ); } ?> </div>
						<div class="col-md-2 col-sm-3"> <?php if ( is_active_sidebar('footersb6') ) { dynamic_sidebar( 'footersb6' ); } ?> </div> 
						*/?>
					</div>
					<?php } ?>
					<div class="col-md-3 col-xs-12">
						<?php if ( is_active_sidebar('footersb7') ) { dynamic_sidebar( 'footersb7' ); } ?>
					</div>
				</div>
			</div>


			<div class="copyrights">
				<div class="container">
					<div class="row">
						<?php if(!is_mobile()) { ?>
						<div class="col-md-6 col-sm-6 rightext">
							<span><?php echo do_shortcode( get_field('optage_footer_copyrights', 'option') ); ?></span>
						</div>
						<?php } ?>
						<div class="col-md-6 col-sm-6 socialize">
							<ul class="list-inline">

								<?php $socialGroup = get_field('optage_social_accounts', 'option'); ?>

								<li><a href="<?php echo $socialGroup['optage_social_yt']; ?>" target="_blank" rel="nofollow"><i class="fa fa-youtube-play"></i></a></li>
								<li><a href="<?php echo $socialGroup['optage_social_lk']; ?>" target="_blank" rel="nofollow"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="<?php echo $socialGroup['optage_social_fb']; ?>" target="_blank" rel="nofollow"><i class="fa fa-facebook"></i></a></li>
								<li><a href="<?php echo $socialGroup['optage_social_tw']; ?>" target="_blank" rel="nofollow"><i class="fa fa-twitter"></i></a></li>
							</ul>
						</div>
						<?php if(is_mobile()) { ?>
							<div class="col-xs-12">
								<?php if ( is_active_sidebar('footersb8') ) { dynamic_sidebar( 'footersb8' ); } ?>
							</div>
							<div class="col-xs-12 mobile-copyrights"><?php echo do_shortcode( get_field('optage_footer_copyrights', 'option') ); ?></div>
						<?php } ?>
					</div>
				</div>
			</div>

		</div>
	</footer>
			

			

	</div> <!-- // .body-container -->

	<!--=== WP FOOTER ===-->
	<?php wp_footer(); ?>
	<!--=== WP FOOTER ===-->


	<!--=== CUSTOM FOOTER SCRIPTS ===-->
	<?php
	wp_reset_query();
	$footerScripts = get_field('optage_footer_scripts', 'option');
	if($footerScripts) { echo $footerScripts; }
	?>
	<!--=== CUSTOM FOOTER SCRIPTS ===-->


	<!--=== ON PAGE FOOTER SCRIPTS ===-->
	<?php
	$pageFooterScripts = get_field('common_footer_scripts', get_the_ID());
	if($pageFooterScripts) { echo '<script>'.$pageFooterScripts.'</script>'; }


	// ALL SPECS CUSTOM SCRIPTS: MANAGED IN THEME OPTIONS
	if(is_singular('specs')) {
		$globalSpecsFooterScripts = get_field('globalspecs_footer_scripts', 'option');
		if($globalSpecsFooterScripts) { echo $globalSpecsFooterScripts; }	
	}
	?>
	<!--=== ON PAGE FOOTER SCRIPTS ===-->




</body>
</html>