<?php
class sgFeaturedSliderWidget extends WP_Widget {
	
	
	
	// DEFINE THE WIDGET
	function __construct() {
		$widget_ops = array(
			'classname' 	=> 'sg_featuredslider_widg',
			'description'	=> __('A Custom widget created for featured slider By SITEIT', 'siteitsob')
		);
		
		parent::__construct('sgFeaturedSliderWidget', __('Featured Slider Widget (SiteIT)', 'siteitsob'), $widget_ops);
	}
	
	
	// auto build select array
	function sghttibgw_create_numstring_array($startNum, $endNum, $jumps, $sideString = NULL) {
		
		if($startNum && $endNum) {
			
			$data       = array();
			$counter    = $startNum;
			
			
			while($endNum > $counter ) {
				$data[$counter] = $counter.' '.$sideString;
				$counter        = $counter + $jumps;
			}
			
			return $data;
		}
	}
	
	
	
	// BUILD MARGIN or PADDING ARRAY
	function build_margpad_array($top, $right, $bottom, $left, $type) {
		$result  				= '';
		$arr[$type.'-top'] 		= $top;
		$arr[$type.'-right'] 	= $right;
		$arr[$type.'-bottom'] 	= $bottom;
		$arr[$type.'-left'] 	= $left;
		$arr 					= array_filter($arr);
		
		if(!empty($arr)) {
			foreach($arr as $key => $value) {
				$result .= $key.':'.$value.'px;';
			}
		}
		
		return $result;
	}
	
	
	
	function siteit_widget_fields() {
		return array(
			'use_mobile',
		);
	}
	
	
	// SPEW OUT FIELDS TWICE: Desktop & Mobile
	// VERSION = desktop / mobile
	function form_fileds_looper($mobile = NULL, $instance) {
		
		
		// rtl fixes
		if(is_rtl()) {$floatDir = 'left';} else {$floatDir = 'right';}
		
		$formFields = '
		<div class="admin-row">
			This widget has no options. All featured slider options are controlled via the <a href="http://a17133-tmp.s100.upress.link/wp-admin/admin.php?page=acf-options" target="_blank">Options Page</a>
		</div>
		';
		
		return $formFields;
	}
	
	
	
	// BUILDING THE WIDGET FORM
	function form($instance) {
		
		$defaults = array();
		
		foreach($this->siteit_widget_fields() as $f) {
			$defaults[$f] = '';
			$defaults['mobile_'.$f] = '';
		}
		
		
		$instanceArray 		= $defaults; // set default values
		$instance 			= wp_parse_args( (array) $instance, $instanceArray );
		
		// widget title
		echo '
		<div>
			<ul class="nav nav-tabs" role="tablist">
				<li role="presentation" class="active"><a href="#desktop-'.$this->id_base.'-'.$this->number.'" aria-controls="desktop" role="tab" data-toggle="tab"> <span class="dashicons dashicons-desktop"></span> '.__('Desktop', 'siteitsob').'</a></li>
				<li role="presentation"><a href="#mobile-'.$this->id_base.'-'.$this->number.'" aria-controls="mobile" role="tab" data-toggle="tab"> <span class="dashicons dashicons-smartphone"></span> '.__('Mobile', 'siteitsob').'</a></li>
			</ul>
			<div class="tab-content">

				<!--===STR================= DESKTOP INPUTS =========================-->
				<div class="tab-pane desktop-settings active" id="desktop-'.$this->id_base.'-'.$this->number.'">
					'.$this->form_fileds_looper(false, $instance).'
				</div>
				<!--===END================= DESKTOP INPUTS =========================-->


				<!--===STR================= MOBILE INPUTS =========================-->
				<div class="tab-pane mobile-settings" id="mobile-'.$this->id_base.'-'.$this->number.'">
					<button class="button-secondary copyToMobile">Copy Desktop Values</button>
					'.$this->form_fileds_looper(true, $instance).'
				</div>
				<!--===END================= MOBILE INPUTS =========================-->

			</div>
		</div>
		';
		
	}
	
	
	// SAVE FORM VALUES
	function update($new_instance, $old_instance) {
		
		$prefix 	= 'mobile_';
		$instance	= $old_instance;
		$fieldNames = $this->siteit_widget_fields();
		
		foreach($fieldNames as $field) {
			$instance[$field]			=	$new_instance[$field];			// save desktop values
			$instance[$prefix.$field]	=	$new_instance[$prefix.$field];	// save mobile values
		}
		
		return $instance;
	}
	
	
	
	
	// DISPLAY THE WIDGET
	function widget($args, $instance) {
		extract($args, EXTR_SKIP);
		
		// BASIC SETTINGS
		$result 		= '';
		$before_widget 	= '<div class="singleWidget sitBuilderWidget featuredSliderWidget '.$mobileView.'">';
		$after_widget  	= '</div>';
		
		if(wp_is_mobile() && $instance['use_mobile'] == 'no') {$prefix = 'mobile_';} else {$prefix = '';}
		if($prefix) {$mobileView = $prefix.'state';} else {$mobileView = 'DesktopState';}
		
		
		
		// get data from options page
		$data                   = get_field('optage_featured_slider', 'option');
		$section['title']       = $data['optage_featured_slider_title'];
		$section['bgimg']       = $data['optage_featured_slider_bgimg'];
		$catalog['label']       = $data['optage_featured_slider_cataloglbl'];
		$catalog['url']         = get_field( 'pdf_file' , $data['optage_featured_slider_catalogfile']->ID);
		$download['link']        = $data['optage_featured_slider_download_link'];
		$products['label']      = $data['optage_featured_slider_linklbl'];
		$products['url']        = $data['optage_featured_slider_linkurl'];
		
		
		// build slider
		$status = 'active';
		$counter		= 0;
		$indicators		= '';
		$items  		= '';
		$slides 		= $data['optage_featured_slider'];
		
		foreach($slides as $slide) {
			
			$slideData = $slide['optage_featured_slider_product'];
			
			if(is_mobile()) {
				$img 		= $slide['optage_featured_slider_productmimg'];
				$imgWebp 	= $slide['optage_featured_slider_productmimg_webp'];
			}
			else {
				$img 		= $slide['optage_featured_slider_productimg'];
				$imgWebp 	= $slide['optage_featured_slider_productimg_webp'];
			}
			
			if($data['optage_featured_slider_download_link']){
				$button_link = '<li><a href="'.$download['link']  .'" class="btn btn-warning btn-lg" id="HomepagePDF"><span>'.$catalog['label'] .'</span></a></li>';
			} else {
				$button_link = '<li><a href="'.$catalog['url'] .'" class="btn btn-warning btn-lg" id="HomepagePDF" target="_blank"><span>'.$catalog['label'] .'</span></a></li>';
			}
			
			$items .= '
            <div class="item slider-item '.$status.'">
                <div class="row">
                    <div class="col-md-4 col-sm-5 col-xs-12">
                        <h4 class="item-title"><a href="'.get_permalink($slideData->ID).'">'.$slideData->post_title.'</a></h4>
                    </div>
                    <div class="col-md-8 col-sm-7 col-xs-12">
						<a href="'.get_permalink($slideData->ID).'">
							<picture class="img-responsive">
								'.( !empty($imgWebp) ? '<source srcset="'.$imgWebp.'" type="image/webp" alt="'.attachment_alt_fromurl($img).'" class="'.(is_mobile() ? 'img-responsive' : '').'">' : '' ).'
								<img src="'.$img.'" alt="'.attachment_alt_fromurl($img).'" class="'.(is_mobile() ? 'img-responsive' : '').'">
							</picture>
						</a>
                    </div>
                </div>
            </div>
			';
			
			$indicators .= '<li data-target="#featuredSlider" data-slide-to="'.$counter.'" class="'.$status.'"></li>';
			
			$status = '';
			$counter++;
		}
		
		
		// CONTROLLERS (not in mobile)
		if(is_mobile()) {
			$controllers = '
			<ol class="carousel-indicators">
				'.$indicators.'
			</ol>
			';
		}
		else {
			$controllers = '
			<a class="left carousel-control" href="#featuredSlider" role="button" data-slide="prev"> <img src="'.IMG_URL.'/featured-slider-arrow-left.png" alt="Prev Slide"> <span class="sr-only">Previous</span> </a>
			<a class="right carousel-control" href="#featuredSlider" role="button" data-slide="next"> <img src="'.IMG_URL.'/featured-slider-arrow-right.png" alt="Next Slide"> <span class="sr-only">Next</span> </a>
			';
		}
		
		
		
		$result = '
        <div class="featured-slider-box skew-before skew-after" style="background: url('.$section['bgimg'].') 0 0 no-repeat;">
            <div class="container relative">
                <div id="featuredSlider" class="carousel slide carousel-fade" data-ride="carousel">
                    <!-- Wrapper for slides -->
                    <div class="carousel-inner" role="listbox">
                        '.$items.'
                    </div>
					'.$controllers.'
                </div>
                <div class="fixed-data">
                    <h2 class="section-title">'.$section['title'].'</h2>
                    <ul class="lsnone p0 m0">
                        ' . $button_link . '
                        <li><a href="'.$products['url'] .'" class="btn btn-default btn-lg" id="viewProducts"><span>'.$products['label'] .'</span></a></li>
                    </ul>
                </div>

            </div>
        </div>
        ';
		
		
		echo $before_widget.$result.$after_widget;
		
	}
	
}
add_action( 'widgets_init', create_function('', 'return register_widget("sgFeaturedSliderWidget");') );
?>