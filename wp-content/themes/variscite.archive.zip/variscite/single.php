<?php
get_header();

// GET POST CATEGORY
$pid = get_the_id();
$cat = get_the_category($pid);

?>

	<div class="single-box">

		<div class="container">
			
			<?php if(!is_mobile()) {echo breadcrumbs();} ?>

			<div class="row relative">

				<!--===STR===== SIDEBAR MODAL ===========-->
				<div class="modal fade" id="mobileSidebarModal" tabindex="-1" role="dialog" aria-labelledby="mobileSidebarModalLabel">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							</div>
							<div class="modal-body">
								<div class="mobile-category-sidebar">
									<?php if ( is_active_sidebar( 'blogsidebarmobile' ) ) { dynamic_sidebar( 'blogsidebarmobile' ); } ?>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--===END===== SIDEBAR MODAL ===========-->
				
				<?php
				if(is_mobile()) {
					echo '
				<div class="col-md-12 mtitle-box">
					<div class="row">
						<div class="col-xs-9"><h4>'.$cat[0]->name.'</h4></div>
						<div class="col-xs-3 pr0 text-right">
							<ul class="mcatActionList list-inline">
								<li class="rss"><a href="'.get_field('optage_rss_url', 'option').'"><i class="fa fa-rss"></i></a></li>
								<li class="ssearch"><button class="btn btn-link" id="showMobileSidebar" data-toggle="modal" data-target="#mobileSidebarModal"><img src="'.IMG_URL.'/search.png" alt="Search"></button></li>
							</ul>
						</div>
					</div>
				</div>
				';
				}
				else {
					echo '
                <div class="col-md-12 cat-title hidden-sm"><h4>'.$cat[0]->name.'</h4></div>

				<div class="col-md-12 col-sm-12 visible-sm mtitle-box clearfix">
					<div class="row">
						<div class="col-xs-9"><h4>'.$cat[0]->name.'</h4></div>
						<div class="col-xs-3 pr0 text-right">
							<ul class="mcatActionList list-inline">
								<li class="rss"><a href="'.get_field('optage_rss_url', 'option').'"><i class="fa fa-rss"></i></a></li>
								<li class="ssearch"><button class="btn btn-link" id="showMobileSidebar" data-toggle="modal" data-target="#mobileSidebarModal"><img src="'.IMG_URL.'/search.png" alt="Search"></button></li>
							</ul>
						</div>
					</div>
				</div>
                ';
				}
				?>



				<div class="col-md-8 post-loop">
					<?php
					if ( have_posts() ) {
						while ( have_posts() ) {
							the_post();
							
							// ITEM DATA
							$pid 		= get_the_ID();
							$title 		= get_the_title();
							$link 		= get_permalink();
							$date 		= get_the_date( 'l, d M Y', $pid );
							$cat 		= get_the_category();
							$content    = get_the_content();
							
							// THUMB SIZES
							$thumb_mobile = '';
							$thumb_desktop = '';
							
							// if(is_mobile()) { $thumb = smart_thumbnail( $pid, 450, 235, '', '', get_field('optage_defaults_blog_image', 'option') ); }
							// else { $thumb = smart_thumbnail( $pid, 215, 130, '', '', get_field('optage_defaults_blog_image', 'option'), true ); }
							
							$thumb = smart_thumbnail( $pid, 450, 235, '', $title, get_field('optage_defaults_blog_image', 'option') );
							
							// NEXT & PREV LINKS
							$prev_post = get_adjacent_post(true,'',true, 'category');
							$next_post = get_adjacent_post(true,'',false, 'category');
							
							
							$title_block = '
                        <div class="post-title">
                            <div class="row">
                                <div class="col-md-9 col-sm-8 col-xs-12">
                                    <h1>'.$title.'</h1>
                                </div>
                                <div class="col-md-3 col-sm-4 col-xs-12 m-px-0">
                                    <div class="posthumb">'.$thumb.'</div>
                                </div>
                            </div>
                        </div>
                        ';
							
							
							$meta_block = '
                        <div class="title-meta">
                            <div class="row">
                                <div class="col-md-9 col-md-12">
                                    <div class="row">
                                        <div class="col-md-4 postdate">'.$date.'</div>
                                        <div class="col-md-5 catname"><span>'.__('Category:', THEME_NAME).'</span> <strong>'.$cat[0]->name.'</strong></div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-12">
                                    <ul class="list-inline share-list">
                                    <li><a href="https://www.facebook.com/sharer/sharer.php?u='.urlencode($link).'" target="_blank" class="share-btn"> <i class="fa fa-facebook"></i> <span class="hidden-xs">'.__('Share', THEME_NAME).'</span> </a></li>
                                    <li><a href="https://twitter.com/intent/tweet?text='.urlencode($title).'&url='.urlencode($link).'" target="_blank" class="share-btn"> <i class="fa fa-twitter"></i> <span class="hidden-xs">'.__('Tweet', THEME_NAME).'</span> </a></li>
                                    <li><a href="https://www.linkedin.com/shareArticle?url='.urlencode($link).'&title='.urlencode($title).'" target="_blank" class="share-btn"> <i class="fa fa-linkedin"></i> <span class="hidden-xs">'.__('Post', THEME_NAME).'</span> </a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        ';
							
							
							$content_block = '
                        <div class="post-content">
                            '.apply_filters('the_content', $content).'
                        </div>
                        ';
							
							
							$postnav_links = '
                        <div class="postnav-links">
                            <div class="row">
                                <div class="col-md-5 col-xs-12 center-block text-center">
                                    <ul class="list-inline p0 m0">
                                        '.( !empty($prev_post) ? '<li><a href="'.get_permalink( $prev_post->ID ).'"><i class="fa fa-angle-left"></i> '.__('Previous Post', THEME_NAME).'</a></li>' : '' ).'
                                        '.( !empty($next_post) ? '<li><a href="'.get_permalink( $next_post->ID ).'">'.__('Next post', THEME_NAME).' <i class="fa fa-angle-right"></i></a></li>' : '').'
                                    </ul>
                                </div>
                            </div>
                        </div>
                        ';
							
							echo $title_block.$meta_block.$content_block.$postnav_links;
							
						}
					}
					?>
				</div>
				
				<?php if(!is_mobile()) { ?>
					<div class="col-md-3 category-sidebar hidden-sm">
						<?php if ( is_active_sidebar( 'blogsidebar' ) ) { dynamic_sidebar( 'blogsidebar' ); } ?>
					</div>
				<?php } ?>

			</div>

		</div>

	</div>


<?php get_footer(); ?>