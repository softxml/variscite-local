<?php
/*
Template Name: Home Page
*/
get_header();


	if ( have_posts() ) {
		while ( have_posts() ) { 
			the_post();

			the_content();
		}
	}


	if(!is_mobile() && get_field('hide_side_strip', get_the_ID()) != 'on') {
		include(THEME_PATH.'/parts/side-strip.php');
	}



	// SOCIAL DATA FOR SCHEMA
	$social = get_field('optage_social_accounts', 'option');

	echo '
	<script type="application/ld+json">
	{
		"@context": "http://schema.org",
		"@type": "Organization",
		"url": "https://www.variscite.com",
		"logo": "https://www.variscite.com/wp-content/uploads/2018/09/Logo-Variscite.png",
		"contactPoint": [{
		"@type": "ContactPoint",
		"telephone": "+972-9-9562910",
		"email": "sales@variscite.com", 
		"contactType": "customer service"
		}],
		"sameAs": [
			"https://www.youtube.com/c/VarisciteLtd",
			"https://www.linkedin.com/company/variscite-ltd-/",
			"https://www.facebook.com/Variscite-Ltd-323442114434181/",
			"https://www.xing.com/companies/variscite",
			"https://twitter.com/Variscite_Ltd"
		]
	}
	</script>
	
	';

get_footer(); ?>