<?php
get_header();

$fields 		= get_field_objects(get_the_ID());
?>

<?php
if ( have_posts() ) {
	while ( have_posts() ) {
		the_post();

		$pid 				= get_the_ID();
		$ptitle				= get_the_title();
		$thumburl			= get_the_post_thumbnail_url( $pid, 'full' );
		$pterms				= wp_get_post_terms($pid, 'products');
		$ptermId			= $pterms[0]->term_id;
		$post_meta 			= get_post_meta($pid);

		$kit_check			= get_field('vrs_specs_evaluation_kit', $pid);
		$isit_kit			= ( !empty($kit_check[0]) && $kit_check[0] == 'evkit' ? true : false );

		$store_inlink		= get_field('vrs_specs_instore_product', $pid);
		$store_exlink		= get_field('vrs_specs_exstore_product', $pid);
		$button_text		= get_field('vrs_specs_button_text', $pid);

		$hide_compare 		= get_field('hide_compare_link', $pterms[0]);
		$local_compliance 	= get_field('global_compliance_icons', $pid);
		?>
		
		<div class="specs-page <?php if( !empty(get_field('vrs_specs_store_product')) ) {echo 'cart-product';} else {echo 'quote-product';} ?>">
			<div class="inner">

					<!--===STR=============== GENERAL INFO =====================-->
					<div id="general-info" class="section-box">

						<div class="container-wrap hidden-xs">
							<div class="container">
								<div class="breadcrumbs"><?php echo breadcrumbs(); ?></div>
							</div>
						</div>

						<?php specs_topbgimg_style(get_field('vrs_specs_headimg')); ?>

						<div class="top-slider">
							<div class="container-wrap">
								<div class="container">
									<div class="row">
										<div class="col-md-4 col-sm-6 col-xs-12">

											<h1 class="page-title"><?php echo specs_page_title(get_the_title()); ?></h1>
											<?php
											if( !empty(get_field('vrs_specs_price')) ) { echo '<div class="price-block">'.get_field('vrs_specs_price').'</div>'; }
											
											// DESKTOP GET QUOTE BTN
											custom_getquote_btn($kit_check, $store_inlink, $store_exlink, $button_text, 'hidden-xs hidden-sm');

											/* <button class="btn btn-warning btn-lg quote-scroll scroll " data-to="quote-tabs"><span class="text"><?php _e('Get a quote', THEME_NAME); ?></span> <img src="<?php echo IMG_URL; ?>/button-arrow.png" alt="arrow"></button> */
											?>

											<?php if( empty($hide_compare[0]) || $hide_compare[0] != 'on') { ?>
												<?php if(!is_mobile()) { ?>
												<button class="btn btn-link specsComapre btn-lg cFF" value="<?php echo $pid; ?>"><?php _e('Compare to other products', THEME_NAME); ?></button>
												<a href="<?php echo get_permalink( get_field('optage_defaultpages_compare', 'option') ); ?>" id="productsCompare" class="dnone"></a>
												<?php } ?>
											<?php } ?>

										</div>
										<div class="col-md-1 hidden-sm"></div>
										<div class="col-md-7 col-sm-6 col-xs-12">
											<?php echo specs_product_slider( $pid ); ?>

											<button class="btn btn-warning btn-lg quote-scroll scroll visible-xs" data-to="quote-tabs"><span class="text"><?php _e('Get a quote', THEME_NAME); ?></span> <img src="<?php echo IMG_URL; ?>/button-arrow.png" alt="arrow"></button>
											<button class="btn btn-warning btn-lg quote-scroll scroll visible-sm" data-to="quote-tabs"><span class="text"><?php _e('Get a quote', THEME_NAME); ?></span> <img src="<?php echo IMG_URL; ?>/button-arrow.png" alt="arrow"></button>

										</div>
									</div>
								</div>
							</div>
						</div>


						<?php if( empty($hide_compare[0]) && $hide_compare[0] != 'on' && is_mobile() ) { ?>
						<div class="text-center mt5">
							<button class="btn btn-link specsComapre btn-lg c0d" value="<?php echo $pid; ?>"><?php _e('Compare to other products', THEME_NAME); ?></button>
							<a href="<?php echo get_permalink( get_field('optage_defaultpages_compare', 'option') ); ?>" id="productsCompare" class="dnone"></a>
						</div>
						<?php } ?>
			
						<?php if(get_field('vrs_specs_product_middesc')) { ?>
						<div class="top-desc">
							<div class="container-wrap">
								<div class="container">
									<div class="row">
										<div class="product-datapdf col-md-3 col-sm-3">
											<ul class="lsnone p0">
												<?php
												// VALUES RETUNED ARE POST IDS OF RELEVANT PDF'S
												$pdf['brief'] 		= get_field('vrs_specs_product_brief');
												$pdf['datasheet'] 	= get_field('vrs_specs_product_datasheet');
												$pdf['quickstart'] 	= get_field('vrs_specs_quickstart_guide');
												$pdf['wiki'] 		= get_field('vrs_specs_wiki_page');
												$pdf['schematics'] 	= get_field('vrs_specs_board_schematics');

												if( !empty($pdf['brief']) ) {echo '<li><a href="'.product_data_pdf( $pdf['brief'] ).'" target="_blank" class="btn btn-default btn-lg datapdf-btn"><span class="text">'.__('Product Brief', THEME_NAME).'</span> </a></li>';}
												if( !empty($pdf['quickstart']) ) {echo '<li><a href="'.product_data_pdf( $pdf['quickstart'] ).'" target="_blank" class="btn btn-default btn-lg datapdf-btn"><span class="text">'.__('Quick Start Guide', THEME_NAME).'</span> </a></li>';}
												if( !empty($pdf['datasheet']) ) {echo '<li><a href="'.product_data_pdf( $pdf['datasheet'] ).'" target="_blank" class="btn btn-default btn-lg datapdf-btn"><span class="text">'.__('Product Datasheet', THEME_NAME).'</span></a></li>';}
												if( !empty($pdf['wiki']) ) {echo '<li><a href="'.$pdf['wiki'].'" target="_blank" class="btn btn-default btn-lg datapdf-btn"><span class="text">'.__('Wiki Page', THEME_NAME).'</span></a></li>';}
												if( !empty($pdf['schematics']) ) {echo '<li><a href="'.product_data_pdf( $pdf['schematics'] ).'" target="_blank" class="btn btn-default btn-lg datapdf-btn"><span class="text">'.__('Board Schematics', THEME_NAME).'</span></a></li>';}
												?>
											</ul>
										</div>

										<?php if(is_mobile()) { ?>
										<div class="product-compliance col-md-3">
											<?php if( !empty(get_field('vrs_specs_compliance_icons')) ) {echo specs_compliance_icons(get_field('vrs_specs_compliance_icons'), $local_compliance);} ?>
										</div>
										<?php } ?>

										<div class="product-desc col-md-6 col-sm-6">
											<?php if( !empty(get_field('vrs_specs_product_middesc')) ) {echo apply_filters('the_content', get_field('vrs_specs_product_middesc'));} ?>
										</div>

										<?php if(!is_mobile()) { ?>
										<div class="product-compliance col-md-3 col-sm-3">
											<?php if( !empty(get_field('vrs_specs_compliance_icons')) ) {echo specs_compliance_icons(get_field('vrs_specs_compliance_icons'), $local_compliance);} ?>
										</div>
										<?php } ?>

									</div>
								</div>
								<div class="clearfix"></div>
							</div>
						</div>
						<?php } ?>

					</div>
					<!--===END=============== GENERAL INFO =====================-->

			

					<!--===STR=============== SPECIFICATION =====================-->
					<div id="specification" class="skew-before skew-after section-box <?php if(!get_field('vrs_specs_product_middesc')) { echo 'noDescProd';} ?>  <?php if(empty($accessoriesArr[0]['accessory']) && empty(get_field('vrs_specs_doc_block')) && empty(get_field('vrs_specs_relevant_mid_product')) ) {echo 'plus2-sections-spacing';} ?>">
						<div class="container-wrap">
							<div class="container"><h2 class="section-title"> <?php if( !empty(get_field('vrs_specs_spec_title')) ) {the_field('vrs_specs_spec_title'); } else { _e('Specification', THEME_NAME);} ?> </h2></div>
							<?php echo specs_specification_tabs( get_field('vrs_specs_spec_tabs'), $pid ); ?>
							
							<div class="clearfix"></div>
						</div>

						<?php
						if($isit_kit) {
							if( !empty($store_inlink) || !empty($store_exlink)) {

								echo '
								<div class="buykit-bar">
									<div class="inner">
										<div class="row">
											<div class="col-md-6 col-xs-6 cta-text">
												<span>' . __('Order your Evaluation Kit', THEME_NAME) . '</span>
											</div>
											<div class="col-md-6 col-xs-6">
												<div class="btn-wrap">
												<a href="'.( !empty($store_exlink) ? $store_exlink : get_permalink(get_field('vrs_specs_instore_product')) ).'" '.( !empty($store_exlink) ? 'target="_blank"' : '').' class="btn btn-default"><span>' . __('Add to cart', THEME_NAME) . '</span></a>
												</div>
											</div>
										</div>
									</div>
								</diV>
								<div class="clearfix"></div>
								';
							}
						}
						?>

					</div>
					<!--===END=============== SPECIFICATION =====================-->


					<!--===STR=============== EVALUATION KIT =====================-->
					<?php
					$kit_postid = get_field('vrs_specs_relevant_mid_product');

					if($kit_postid) {
						echo spec_evaluation_kit($kit_postid , get_field('vrs_specs_evaluation_kit_cimg'), get_field('vrs_specs_evaluation_kit_cimg_webp'), get_field('vrs_specs_relevant_mid_prodalturl') );
					}
					?>
					<!--===END=============== EVALUATION KIT =====================-->

					

					<!--===STR=============== DOCUMANTATION =====================-->
					<?php if( !empty(get_field('vrs_specs_doc_block')) ) { ?>
					<div id="documantation" class="section-box">
						<div class="container-wrap">
							<div class="container">
								<?php echo spec_docs_boxes( get_field('vrs_specs_doc_block'), $pid ); ?>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
					<?php } ?>
					<!--===END=============== DOCUMANTATION =====================-->

					

					<!--===STR=============== ACCESSORIES =====================-->
					<?php
					$accessoriesArr = get_field('vrs_specs_accesories_products');


					if( !empty($accessoriesArr[0]['accessory']) ) {
						echo '
						<div class="spacer s22211"></div>
						<div id="accessories" class="section-box">'.specs_accessories_slider( get_field('vrs_specs_accesories_products'), $pid ).'</div>
						';
					}
					?>
					<!--===END=============== ACCESSORIES =====================-->


					<!--===STR=============== QUOTE FORM =====================-->
					<div id="quote-formbox" class="section-box relative <?php if(empty($accessoriesArr[0]['accessory']) && empty(get_field('vrs_specs_doc_block')) && empty(get_field('vrs_specs_relevant_mid_product')) ) {echo 'min2-sections-spacing';} ?>   <?php if( empty($accessoriesArr[0]['accessory']) ) {echo 'no-accessories-section';} ?>">
						<div class="quote-background">
							<div class="row">
								<div class="col-md-6 cell-1"></div>
								<div class="col-md-6 cell-2"></div>
							</div>
						</div>
						<div id="get-a-quote" class="form-box">
							<div class="container-wrap">
								<div class="container">
									<div class="row">
										<div class="quote-title-box col-md-2 p0 col-xs-12">
											<h2 class="section-title"><?php the_field('vrs_specs_quote_title'); ?></h2>
											<p class="section-desc"><?php the_field('vrs_specs_quote_desc'); ?></p>
										</div>
										<div class="vspacer col-md-1 hidden-xs">
											<!--===SPACER===-->
										</div>
										<div class="quote-form-row col-md-9 col-xs-12">
											<?php echo specs_quoteform_box( get_field('vrs_specs_quote_product_addons'), get_the_ID() ); ?>
										</div>
									</div>
								</div>

								<div class="clearfix"></div>
							</div>
						</div>
					</div>
					<!--===END=============== QUOTE FORM =====================-->

					<div class="spacer s22211 relSpacer"></div>

					<!--===STR=============== RELATED =====================-->
					<div id="related" class="section-box">
						<div class="container-wrap">
							<div class="container">
								<?php echo specs_related_products( get_field('vrs_specs_related_products'), $pid ); ?>
							</div>

							<div class="clearfix"></div>
						</div>
					</div>
					<!--===END=============== RELATED =====================-->

			</div>



			<!--===STR=============== SIDE SCROLL NAV =====================-->
			<?php if( !is_mobile() ) { ?>
			<div class="sideScrollNav">
				<div class="inner">
					<ul class="lsnone p0 m0">
						<li id="nav-general-info" class="side-scroll" data-to="general-info"><?php _e('General info', THEME_NAME); ?></li>
						<li id="nav-specification" class="side-scroll" data-to="specification"><?php _e('Specifications', THEME_NAME); ?></li>
						<?php
						if( !empty(get_field('vrs_specs_relevant_mid_product')) ) {echo '<li id="nav-evaluation-kit" class="side-scroll" data-to="evaluation-kit">'.__('Evaluation Kit', THEME_NAME).'</li>';}
						if( !empty(get_field('vrs_specs_doc_block')) ) {echo '<li id="nav-documantation" class="side-scroll" data-to="documantation">'.get_field('vrs_specs_doc_section_title').'</li>';}
						if( !empty(get_field('vrs_specs_accesories_products')[0]['accessory']) ) {echo '<li id="nav-accessories" class="side-scroll" data-to="accessories">'.get_field('vrs_specs_accesories_title').'</li>';}
						?>
						<li id="nav-quote-formbox" class="side-scroll" data-to="get-a-quote"><?php the_field('vrs_specs_quote_title'); ?></li>
					</ul>
				</div>
			</div>
			<?php } ?>
			<!--===END=============== SIDE SCROLL NAV =====================-->


	</div>
	<?php
	}
}
?>






<script type="text/javascript">
var onloadCallback = function() {
	grecaptcha.render('captcha', {
		'sitekey' : '6Lc9usIUAAAAAPM1xJlaO-rMZKfjJVzL0tTX42Wx',
		//'sitekey' : '<?php //echo get_field('recaptcha_key', 'option'); ?>//',
		'callback' : grabCaptchaRes
	});
	//console.log("REC sitekey=" + <?php //echo get_field('recaptcha_key', 'option'); ?>//);
};

function grabCaptchaRes(res) {
	console.log(res);
	var elem = document.getElementById("captachResponse");
	elem.value = res;
}
</script>


<script>




jQuery(function($){
//sidenav click functions
    //original location for  SIDENAV SCROLL WITH HASH


	/*************************************************
	** TOGGLE BUTTON STATUS (IN QUOTE FORM)
	*************************************************/
	$('.opsysBtns button').click(function() {
		$(this).toggleClass('active');
		$('.opsysBtns button').not(this).removeClass('active');
	});

});


jQuery(document).ready(function($) {


	/*************************************************
	** COMBINE TH CELLS IN "ordering_info" TAB
	** AND ADD COLSPAN ACCRODINGLY
	*************************************************/
	var thCount = 1;
	$('.tab-pane#ordering_info thead th').each( function(index) {
		var ctxt = $(this).text();
		if(ctxt == '') { thCount = thCount + 1; $(this).remove(); }
		$('.tab-pane#ordering_info thead th:first-child').attr('colspan', thCount);
	});



	/*************************************************
	** ACCESSORIES SLIDER
	*************************************************/
	if( $('#accesoriesSlider').length > 0 ) {
		$('#accesoriesSlider').bxSlider({
			<?php
			if(is_mobile()) {
				echo "
				centeredSlides: true,
				slidesPerView:'auto',
				slideWidth: 225,
				";
			} else {
				echo "
				minSlides: 4,
				maxSlides: 4,
				slideWidth: 900,
				";
			}
			?>
			moveSlides: 1,
			slideMargin: 0,
			pager: false,
            touchEnabled: <?php echo (is_mobile() ? 'true' : 'false'); ?>,
			controls: <?php echo (is_mobile() ? 'false' : 'true'); ?>,
			nextText: '<i class="fa fa-angle-right"></i>',
			prevText: '<i class="fa fa-angle-left"></i>',
		});
	}


	if( $('#relatedMobileSlider').length > 0 ) {
		$('#relatedMobileSlider').bxSlider({
			<?php
			if(is_mobile()) {
				echo "
				centeredSlides: true,
				slidesPerView:'auto',
				slideWidth: 225,
				";
			} else {
				echo "
				minSlides: 4,
				maxSlides: 4,
				slideWidth: 900,
				";
			}
			?>
			moveSlides: 1,
			slideMargin: 0,
			pager: false,
			controls: false,
		});
	}



	// FIX TAB ITEMS AND SPACING
	<?php if(!is_mobile()) { ?>
	if( $('.specs-wrap').length > 0 ) {

		var tabsCount = $('.specs-wrap .nav-tabs li')
		
		if(tabsCount < 6) {
			var newWidth = (tabsCount / 100) + '%';
		}
	}
	<?php } ?>




	<?php if(is_mobile()) { ?>
	$('.product-desc').readmore({
		speed: 75,
		collapsedHeight: 155,
		moreLink: '<a href="#" class="rmExpend">Read More</a>',
		lessLink: '<a href="#" class="rmExpend">Read less</a>'
	});



	// slider toggle sub-tables
	$('thead.sub-table').each(function() {
		if( !$(this).hasClass('open') ) {  $(this).nextUntil('thead.sub-table').slideToggle(50);  }
	});
	$('.sub-table').click(function(){
		$(this).nextUntil('thead.sub-table').slideToggle(50);
		$(this).toggleClass('open');
	});
	<?php } ?>


    /******************
     * my Function
     */

    function scrollToPosition (element){
        var distance=0;
        if (element == '#general-info'){
            distance = getPosition(element) - getDesktopMenuOffset();
            //console.log("general-info position: " + distance);
        }else {
            // if(element == '#get-a-quote') {element = element  + " .section-title";distance = getPosition(element) - getDesktopMenuOffset();}
            // else if(element == '#specification') {element = element  + " .section-title";distance = getPosition(element);}
            // else if(element == '#evaluation-kit') {element = element  + " .section-title";distance = getPosition(element) - 450;}
            // else {element = element  + " .section-title";distance 	= getPosition(element) - 220;}
            distance  = getPosition(element) - getDesktopMenuOffset() -50;
            //console.log(element + " .section-title position: " + distance);
        }

        //distance 	= $(elementId).offset().top - 90;
        return distance;
    }
function getPosition(element){
        //console.log($(element));
        return $(element).offset().top;
}

function getDesktopMenuOffset(){
        return $('#desktopMenuWrap').outerHeight();
    }
    /*************************************************
     ** SIDENAV SCROLL WITH HASH
     *************************************************/
    $('.side-scroll').click(function(e) {
        e.preventDefault();
        var parentElementId = '#' + $(this).data('to');
        var scrollto, scrolltoID;

        if (parentElementId == '#general-info'){
            scrollto 	= parentElementId;
            scrolltoID 	= parentElementId;
        } else if (parentElementId == '#documantation'){
            scrollto 	= parentElementId;
            scrolltoID 	= parentElementId;
        }else {
            scrollto = parentElementId + ' .section-title';
            scrolltoID 	= parentElementId;
        }

        var positon = getPosition(scrollto) - getDesktopMenuOffset() - 70;
        if(scrolltoID === '#documantation'){
            positon = positon + 225
        }
        $(':not(:animated),body:not(:animated)').animate({ scrollTop: positon }, 1000);
        history.pushState(null, null, scrolltoID);
        return false;
    });


//scroll functions

	function is_visible(el){
	    el = "#" + el[0].id;
        var top_of_element = $(el).offset().top;
        var bottom_of_element = $(el).offset().top + $(el).outerHeight();
        var bottom_of_screen = $(window).scrollTop() + $(window).innerHeight();
        var top_of_screen = $(window).scrollTop();

        if ((bottom_of_screen > top_of_element) && (top_of_screen < bottom_of_element)){
            return 'true';
        } else {
            return 'false';
        }
	}
	
    function getViewportAnchor() {
        var scroll = $(window).scrollTop();
        var windowHeight = $(window).height() * .7;
        var windowHeightDefault = windowHeight;
        var elements = $(".section-box");
        var el;
        for (var i=0; i<elements.length; i++) {
            el = $(elements[i]);
            var if_is_visible = is_visible(el);
            var elminusheight = el.offset().top - windowHeight;
            //console.log("EL = " + el[0].id + " && windowheight = " + $(window).height() + " && winheight = " + windowHeight + " && Scroll = " + scroll + " && ElOffset = " + el.offset().top + " && el.offset - windowHeight = " + elminusheight + " && if_is_visible = " + if_is_visible);
	        if(el[0].id === "documantation"){windowHeight = $(window).scrollTop() * .3 } else {windowHeight = windowHeightDefault}
	        //console.log(el[0].id + ' el is visible: ' + if_is_visible);
            if (el.offset().top + windowHeight >= scroll && if_is_visible === 'true'){
                var el_next = $(elements[i+1]);
                if(el_next[0] && el_next[0].id === "documantation"){windowHeight = $(window).scrollTop() * .3 } else {windowHeight = windowHeightDefault}
                if (el_next[0] && el_next.offset().top + windowHeight <= scroll && is_visible(el_next) === 'true'){
                    //console.log(el_next[0].id + ' el_next is visible: ' + if_is_visible);
                    return el_next[0].id;
                    break;
                }
                if_is_visible = 'false';
                return el[0].id;
                break;
            }
        }
    }


    function nav_map_sections(){
        var cSection = getViewportAnchor();
        var cSectionId = '#nav-' + cSection;

        //console.log(cSection);

        if(!$(cSectionId).hasClass('active')) {
            $('.sideScrollNav li').each(function() {
                $(this).removeClass('active');
            });
            //console.log(cSectionId + ' is Active !');
            $(cSectionId).addClass('active');
        }
        if(cSection === undefined){
            console.log(cSection);
            $('.sideScrollNav li').each(function() {
                $(this).removeClass('active');
            });
            $('.section-box').each(function(){
                if(is_visible($(this)) === true){
                    console.log($(this));
                    $('#nav-' + $(this)).addClass('active');
                }
            });
        }
    }

    $(window).scroll(function(){
        nav_map_sections();
    });
    $(window).resize(function(){
        nav_map_sections();
    });
    $("document").ready(function(){
        nav_map_sections();
    });



	// SWIPE SUPPORT IN MOBILE
	<?php if(is_mobile()) { ?>
	$(".carousel").swipe({
		swipe: function(event, direction, distance, duration, fingerCount, fingerData) {

		if (direction == 'left') $(this).carousel('next');
		if (direction == 'right') $(this).carousel('prev');

		},
		allowPageScroll:"vertical"
	});
	<?php } ?>



	/*********************************************
	** ACTIVATE TABS BY LINK
	*********************************************/
	function ezShowTab(tabid) {
		$('#specification .nav-tabs li').removeClass('active');									// 1st: remove active from current tab
		$('#specification .nav-tabs li a[href="'+tabid+'"]').parent().addClass('active');		// 2nd: add active class to current LI nav
		$('#specification .tab-content div.tab-pane').removeClass('active');					// 3rd: remove active class to current TAB
		$('#specification .tab-content div'+tabid+'.tab-pane').addClass('active');				// 4th: add active class to current TAB
		$( tabid ).tab('show');																	// 5th: show tab
	}

	// REPLACE HASH WHEN TAB IS ShOWN
	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		var newhash = $(e.target).attr('href');
		
		if(history.pushState) { history.pushState(null, null, newhash); }
		else { location.hash = newhash; }
	})

	// FIX CUSTOM LINK THAT GOES TO TAB CLICK
	$('#specification .tab-link').click(function(e) {
		e.preventDefault();
		ezShowTab($(this).attr('href'));
	});


	// ONLOAD OPEN - IF HASH == TO TAB -  OPEN TAB
	function checkHashIsTab() {

		var chash = window.location.hash;

		if(chash) {
			var tabslist = [];
		
			$('#specification .nav-tabs li a').each(function() {
				tabslist.push( $(this).attr('href') );
			});
			var exists = tabslist.includes(chash);

			if(exists) {
				ezShowTab(chash);
                setTimeout(function() {
                    parentPos = $('#specification').offset().top;
                    $(window).scrollTop(parentPos);
                },5);
			}
		}

	}
	checkHashIsTab();


});
</script>


<script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit" async defer> </script>

<?php get_footer(); ?>