<?php
/*** DEFINE GLOBAL VARS ***/
@define('THEME_NAME', 'vari');
@define('THEME_PREF', THEME_NAME.'_');
@define('THEME_PATH', get_template_directory());
@define('BASE_URL', get_template_directory_uri());
@define('REL_URL', dirname( __FILE__ ));
@define('IMG_URL', get_template_directory_uri().'/images');



/*********************************************
** 	LOAD FILES IN FOLDER
*********************************************/
function sagive_load_directory($folder_name){
	$theme_root 	= THEME_PATH;
	$files_array = glob("$theme_root/$folder_name/*.php");

	foreach ($files_array as $filename) {
		if ( file_exists( $filename ) ) {
			include($filename);
		}
	}
}


/*********************************************
** 	INCLUDE STUFF
*********************************************/
sagive_load_directory( 'functions' );
sagive_load_directory( 'widgets' );
sagive_load_directory( 'ajax' );




/*********************************************
** 	INCLUDE IN ADMIN
*********************************************/
if(is_admin()) {
	sagive_load_directory( 'functions/acf-ext' );
	sagive_load_directory( 'functions/in-admin' );
}

//function som_page_rewrite($query){
//	$tax = get_queried_object();
//	$tax_id = $tax->term_id;
//	if($tax_id == 43){
//		$query->set( 'post_type', 'page' );
//		$query->set( 'ID', '1418' );
//	}
//}
//add_filter('pre_get_posts', 'som_page_rewrite');

//add_filter('request', function(array $query_vars) {
//	// do nothing in wp-admin
//	if(is_admin()) {
//		return $query_vars;
//	}
//	// if the query is for a category
//	if(isset($query_vars['products']) && $query_vars['products'] == 'system-on-module-som') {
//		// save the slug
//		$pagename = $query_vars['products'];
//		// completely replace the query with a page query
//		$query_vars = array('pagename' => "$pagename");
//	}
//	return $query_vars;
//});

//function change_404_slug($link, $post) {
//	if (is_admin())
//		return $link;
//
//	if (is_404()) {
//		$link = str_replace( '404-2', '404', false);
//		// $link 	= $link['scheme'].'://www.'.$link['host'].$path;
//	}
//	return $link;
//}
//add_filter('post_type_link', 'change_404_slug', 10, 2);

// Disable JSON-LD Yoast SEO schema
function remove_yoast_json_schema($data) {
    $data = array();
    return $data;
}
add_filter('wpseo_json_ld_output', 'remove_yoast_json_schema', 10, 1);

if (isset($_GET['noadminbar'])) {
	add_filter('show_admin_bar', '__return_false');
}

// Add www to all REST API requests to resolve the CORS error returned from Chrome
function variscite_update_rest_api_url($url, $path, $blog_id, $scheme) {
    $url_parts = parse_url($url);

    if(strpos($url_parts['host'], 'www.') == false) {
        $url = $url_parts['scheme'] . '://www.' . $url_parts['host'] . $url_parts['path'];
    }

    return $url;
}
add_filter('rest_url', 'variscite_update_rest_api_url', 10, 4);