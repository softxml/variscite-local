<?php
/***************************************************************************************
 **	GLOBAL AJAX ACTIONS
 ***************************************************************************************/
add_action('wp_enqueue_scripts', 'register_globalajax_scripts');
function register_globalajax_scripts() {
	wp_enqueue_script('global-ajaxfunc', get_stylesheet_directory_uri().'/ajax/global-ajax.js', array('jquery'), 1.1);
	wp_localize_script('global-ajaxfunc', 'ajax_object', array('ajaxurl' => admin_url( 'admin-ajax.php')));
}

add_action('wp_ajax_global_ajaxfunc', 'global_ajaxfunc');
add_action('wp_ajax_nopriv_global_ajaxfunc', 'global_ajaxfunc');
function global_ajaxfunc() {
	
	$lang = ICL_LANGUAGE_CODE;
	$actionType = sanitize_text_field($_POST['action_type']);
	
	
	/*********************************************************
	 **	SEND QUOTE FROM SPECS PAGE
	 *********************************************************/
	if($actionType == 'send_quote') {
		
		$data 		= $_POST['form_data'];
		$uinfo 		= $data['userinfo'];
		$settings	= get_field('quote_settings', 'option');
		
		
		// BUILD USER INFO
		$userinfo = array();
		foreach($uinfo as $info) {
			$c = explode(':', $info, 2);
			
			if($c[0] == 'url') {
				$email[ sanitize_text_field($c[0]) ] = esc_url($c[1]);
			}
			else {
				$email[ sanitize_text_field($c[0]) ] = sanitize_text_field($c[1]);
			}
		}
		
		
		$email['som'] 		= sanitize_text_field( implode(', ', $data['som']) );
		$email['sys']		= sanitize_text_field( implode(', ', $data['sys']) );
		$email['amount'] 	= sanitize_text_field( implode(', ', $data['amount']) );
		
		if( strlen($email['first_name']) < 2 ) { wp_send_json_error( array('msg' => __('Enter a full name.') ) ); }
		elseif( !is_valid_email($email['email']) ) { wp_send_json_error( array('msg' => __('Enter a valid email.') ) ); }
		elseif( empty($email['phone']) ) { wp_send_json_error( array('msg' => __('Enter a valid phone.') ) );}
		else {
			
			
			/*************************
			 ** SAVE EMAIL TO BACKEND
			 **************************/
			$post = array(
				'post_title'    => __('New Lead From', THEME_NAME).': '.$email['first_name'].' '.$email['last_name'],
				'post_status'   => 'publish',
				'post_type'		=> 'leads'
			);
			$lid = wp_insert_post($post, 10, 1);
			do_action('wp_insert_post', 'wp_insert_post', 10, 1);
			
			// user info
			update_field('first_name', $email['first_name'], $lid);
			update_field('last_name', $email['last_name'], $lid);
			update_field('email', $email['email'], $lid);
			update_field('company', $email['company'], $lid);
			update_field('country', $email['country'], $lid);
			update_field('phone', $email['phone'], $lid);
			update_field('note', $email['note'], $lid);
			
			// product info
			update_field('som', $email['som'], $lid);
			update_field('os', $email['sys'], $lid);
			update_field('quan', $email['amount'], $lid);
			
			// custom info
			update_field('curl', $email['url'], $lid);
			update_field('cdevice', $email['device'], $lid);
			update_field('lead_source', $email['leadsource'], $lid);
			update_field('lead_record_created', 'on', $lid);
			
			// campagin info
			update_field('campagin_medium', $email['Campaign_medium__c'], $lid);
			update_field('campagin_source', $email['Campaign_source__c'], $lid);
			update_field('campagin_content', $email['Campaign_content__c'], $lid);
			update_field('campagin_term', $email['Campaign_term__c'], $lid);
			
			if($email['agreement']) {
				update_field('privacy_policy', $email['agreement'], $lid);
			}
			
			/*************************
			 ** SEND EMAIL TO OWNERS
			 **************************/
			$message = '
				<h4>'.__('Sender Information', THEME_NAME).'</h4>
				<ul>
					<li> <strong>From:</strong> '.$email['first_name'].' '.$email['last_name'].'</li>
					<li> <strong>Phone:</strong> '.$email['phone'].'</li>
					<li> <strong>Email:</strong> '.$email['email'].'</li>
					<li> <strong>Company:</strong> '.$email['company'].'</li>
					<li> <strong>Country:</strong> '.$email['country'].'</li>
					<li> <strong>Note:</strong><br> '.$email['note'].'</li>
				</ul>
				<br>

				<h4>'.__('Product Information', THEME_NAME).'</h4>
				<ul>
					<li> <strong>System on Module:</strong> '.$email['som'].'</li>
					<li> <strong>Operating Systems:</strong> '.$email['sys'].'</li>
					<li> <strong>Estimated Quantities:</strong> '.$email['amount'].'</li>
				</ul>
				<br>

				<h4>'.__('Additional Information', THEME_NAME).'</h4>
				<ul>
					<li> <strong>Origin Product:</strong> '.$email['url'].'</li>
					<li> <strong>User Device:</strong> '.$email['device'].'</li>
					<li> <strong>Lead Source:</strong> '.$email['leadsource'].'</li>
				</ul>


				<h4>'.__('Campagin Information (optional)', THEME_NAME).'</h4>
				<ul>
					<li> <strong>Campagin Medium:</strong> '.$email['Campaign_medium__c'].'</li>
					<li> <strong>Campagin Source:</strong> '.$email['Campaign_source__c'].'</li>
					<li> <strong>Campagin Content:</strong> '.$email['Campaign_content__c'].'</li>
					<li> <strong>Campagin Term:</strong> '.$email['Campaign_term__c'].'</li>
				</ul>
				';
			
			$sendResult	= wp_mail($settings['email_to'], '[New Lead from product page] '. $email['company'] . ' [' . strtoupper($lang).']', $message);
			if($sendResult) { update_field('lead_record_email', 'on', $lid);}
			
			
			
			/*************************
			 ** SEND EMAIL TO SALESFORCE
			 **************************/
			
			// REMOVE TEXT AFTER DOTS ":" IN PRODUCT NAME
			$tmpProductNames 	= explode(',', $email['som']);
			$email['som'] = '';
			
			foreach($tmpProductNames as $tmpProdNm) {
				$tmp			= explode(':', $tmpProdNm);
				$email['som'] 	.= $tmp[0].',';
			}
			rtrim($email['som'], ',');
			
			
			// BUILD FIELD FOR CURL URL
//				$fieldURL 	= array();
			
			// CONNECTION STUFF
			$sfdc_data = array(
				'FirstName' => htmlspecialchars($email['first_name']),
				'LastName' => htmlspecialchars($email['last_name']),
				'Company' => htmlspecialchars($email['company']),
				'Email' => htmlspecialchars($email['email']),
				'Country' => ucwords( str_replace('-', ' ', htmlspecialchars($email['country']) )),
				'Phone' => htmlspecialchars($email['phone']),
				'Note__c' => htmlspecialchars($email['note']),
				'System__c' => htmlspecialchars($email['som']),
				'Operating_System__c' => htmlspecialchars($email['sys']),
				'Projected_Quantities__c' => htmlspecialchars($email['amount']),
				'LeadSource' => htmlspecialchars($email['leadsource']),
				'Campaign_medium__c' => htmlspecialchars($email['Campaign_medium__c']),
				'Campaign_source__c' => htmlspecialchars($email['Campaign_source__c']),
				'Campaign_content__c' => htmlspecialchars($email['Campaign_content__c']),
				'Campaign_term__c' => htmlspecialchars($email['Campaign_term__c'])
			);
			
			if($email['agreement']) {
				$sfdc_data['Privacy_Policy__c'] = htmlspecialchars($email['agreement']);
			}

//				$fieldURL[] = 'oid=00D24000000I9Kc';
//				$fieldURL[]	= 'first_name='.$email['first_name'];
//				$fieldURL[]	= 'last_name='.$email['last_name'];
//				$fieldURL[]	= 'company='.$email['company'];
//				$fieldURL[]	= 'email='.$email['email'];
//				$fieldURL[]	= 'country='.ucwords( str_replace('-', ' ', $email['country']) );
//				$fieldURL[]	= 'phone='.$email['phone'];
//				$fieldURL[]	= 'Note__c='.$email['note'];
//				$fieldURL[]	= 'System__c='.$email['som'];
//				$fieldURL[]	= 'Operating_System__c='.$email['sys'];
//				$fieldURL[]	= 'Projected_Quantities__c='.$email['amount'];
//				$fieldURL[]	= 'lead_source='.$email['leadsource'];
//				if( !empty($email['Campaign_medium__c']) ) { $fieldURL[] = 'Campaign_medium__c='.$email['Campaign_medium__c']; }
//				if( !empty($email['Campaign_source__c']) ) { $fieldURL[] = 'Campaign_source__c='.$email['Campaign_source__c']; }
//				if( !empty($email['Campaign_content__c']) ) { $fieldURL[] = 'Campaign_content__c='.$email['Campaign_content__c']; }
//				if( !empty($email['Campaign_term__c']) ) { $fieldURL[] = 'Campaign_term__c='.$email['Campaign_term__c']; }
			// $fieldURL[]	= 'debug=1';
			// $fieldURL[]	= 'retURL='.$email['thanks'];
			
			// RUN CURL
//				$email_string 	= implode ('&', $fieldURL);
//				$ch 			= curl_init();
//
//				$con_url = 'https://webto.salesforce.com/servlet/servlet.WebToLead?encoding=UTF-8';
//				curl_setopt($ch, CURLOPT_URL, $con_url);
//				curl_setopt($ch, CURLOPT_POST, 1);														// Set the method to POST
//				curl_setopt($ch, CURLOPT_POSTFIELDS, $email_string);									// Pass POST data
//				curl_exec($ch); 																		// Post to Salesforce
//
//
//				// RECORD ERRORS OR MARK SENT IN LEAD
//				if (curl_errno($ch)) {
//					update_field('curl_errors_documentation', curl_error($ch), $lid);
//					sfalert_email($lid);
//				}
//				else {
//					$resultStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
//					if ($resultStatus == 200) { update_field('lead_record_sf', 'on', $lid); }
//					else { update_field('curl_errors_documentation', 'Request failed: HTTP status code: ' . $resultStatus, $lid); }
//				}
			
			// Connect to the SFDC SOAP API to pass the lead data
            if(! class_exists('SforceSoapClient')) {
                require_once dirname(__DIR__) . '/inc/soapclient/SforcePartnerClient.php';
            }

			$sfdc_creds = array(
				'user' => 'hadas.s@variscite.com',
				'password' => 'Sh102030',
				'token' => 'FZH6Hm8zOGtOVYa2UADxLF73t'
			);
			
			$sfdc_wsdl = dirname(__DIR__) . '/inc/soapclient/partner.wsdl.xml';
			
			$SFDC = new SforcePartnerClient();
			$SFDC->createConnection($sfdc_wsdl);
			$SFDC->login($sfdc_creds['user'], $sfdc_creds['password'] . $sfdc_creds['token']);
			
			// Init the connection to the API
			try {
				$records = array();
				
				$records[0] = new SObject();
				$records[0]->type = 'Lead';
				$records[0]->fields = $sfdc_data;
				
				$response = $SFDC->create($records);
				
				if($response[0]->success == true){
					update_field('lead_record_sf', 'on', $lid);
				} else {
					update_field('curl_errors_documentation', 'Request failed: HTTP status code: ' . json_encode($response), $lid);
				}
				
			} catch (SoapFault $e) {
				
				# Catch and send out email to support if there is an error
				$errmessage =  "Exception ".$e->faultstring."<br/><br/>\n";
				$errmessage .= "Last Request:<br/><br/>\n";
				$errmessage .= $SFDC->getLastRequestHeaders();
				$errmessage .= "<br/><br/>\n";
				$errmessage .= $SFDC->getLastRequest();
				$errmessage .= "<br/><br/>\n";
				$errmessage .= "Last Response:<br/><br/>\n";
				$errmessage .= $SFDC->getLastResponseHeaders();
				$errmessage .= "<br/><br/>\n";
				$errmessage .= $SFDC->getLastResponse();
				
				update_field('curl_errors_documentation', json_encode($errmessage), $lid);
				sfalert_email($lid);
				
			} catch (Exception $e) {
				
				# Catch and send out email to support if there is an error
				$errmessage =  "Exception ".$e->faultstring."<br/><br/>\n";
				$errmessage .= "Last Request:<br/><br/>\n";
				$errmessage .= $SFDC->getLastRequestHeaders();
				$errmessage .= "<br/><br/>\n";
				$errmessage .= $SFDC->getLastRequest();
				$errmessage .= "<br/><br/>\n";
				$errmessage .= "Last Response:<br/><br/>\n";
				$errmessage .= $SFDC->getLastResponseHeaders();
				$errmessage .= "<br/><br/>\n";
				$errmessage .= $SFDC->getLastResponse();
				
				update_field('curl_errors_documentation', json_encode($errmessage), $lid);
				sfalert_email($lid);
			}
			
			// BUILD RESPONSE
			$resData = array(
				'thanks' => $email['thanks'],
			);
			wp_send_json_success($resData);
			
			curl_close($ch);
			
		}
	}
	
	
	
	/*********************************************************
	 ** XXX
	 *********************************************************/
	if($actionType == 'send_widget_quote') {
		
		$data 		= $_POST['form_data'];
		$settings	= get_field('quote_settings', 'option');
		
		
		foreach($data as $key => $item) {
			if($key == 'note') { $email[$key] = sanitize_textarea_field($item); }
			else { $email[$key] = sanitize_text_field($item); }
		}
		
		
		
		/*************************
		 ** SAVE EMAIL TO BACKEND
		 **************************/
		$post = array(
			'post_title'    => __('New Lead From', THEME_NAME).': '.$email['first_name'].' '.$email['last_name'],
			'post_status'   => 'publish',
			'post_type'		=> 'leads'
		);
		$lid = wp_insert_post($post, 10, 1);
		do_action('wp_insert_post', 'wp_insert_post', 10, 1);
		
		// user info
		update_field('first_name', $email['first_name'], $lid);
		update_field('last_name', $email['last_name'], $lid);
		update_field('email', $email['email'], $lid);
		update_field('company', $email['company'], $lid);
		update_field('country', $email['country'], $lid);
		update_field('phone', $email['phone'], $lid);
		update_field('note', $email['note'], $lid);
		
		// product info
		update_field('som', $email['System__c'], $lid);
		update_field('os', $email['Operating_System__c'], $lid);
		update_field('quan', $email['Projected_Quantities__c'], $lid);
		
		// custom info
		update_field('curl', $email['curl'], $lid);
		update_field('cdevice', $email['cdevice'], $lid);
		update_field('lead_record_created', 'on', $lid);
		
		// campagin info
		update_field('campagin_medium', $email['Campaign_medium__c'], $lid);
		update_field('campagin_source', $email['Campaign_source__c'], $lid);
		update_field('campagin_content', $email['Campaign_content__c'], $lid);
		update_field('campagin_term', $email['Campaign_term__c'], $lid);
		
		if($email['agreement']) {
			update_field('privacy_policy', $email['agreement'], $lid);
		}
		
		/*************************
		 ** SEND EMAIL TO OWNERS
		 **************************/
		$message = '
		<h4>'.__('Sender Information', THEME_NAME).'</h4>
		<ul>
			<li> <strong>From:</strong> '.$email['first_name'].' '.$email['last_name'].'</li>
			<li> <strong>Phone:</strong> '.$email['phone'].'</li>
			<li> <strong>Email:</strong> '.$email['email'].'</li>
			<li> <strong>Company:</strong> '.$email['company'].'</li>
			<li> <strong>Country:</strong> '.$email['country'].'</li>
			<li> <strong>Note:</strong><br> '.$email['note'].'</li>
		</ul>
		<br>

		<h4>'.__('Product Information', THEME_NAME).'</h4>
		<ul>
			<li> <strong>System on Module:</strong> '.$email['System__c'].'</li>
			<li> <strong>Operating Systems:</strong> '.$email['Operating_System__c'].'</li>
			<li> <strong>Estimated Quantities:</strong> '.$email['Projected_Quantities__c'].'</li>
		</ul>
		<br>

		<h4>'.__('Additional Information', THEME_NAME).'</h4>
		<ul>
			<li> <strong>Origin Product:</strong> '.$email['url'].'</li>
			<li> <strong>User Device:</strong> '.$email['device'].'</li>
		</ul>

		<h4>'.__('Campagin Information (optional)', THEME_NAME).'</h4>
		<ul>
			<li> <strong>Campagin Medium:</strong> '.$email['Campaign_medium__c'].'</li>
			<li> <strong>Campagin Source:</strong> '.$email['Campaign_source__c'].'</li>
			<li> <strong>Campagin Content:</strong> '.$email['Campaign_content__c'].'</li>
			<li> <strong>Campagin Term:</strong> '.$email['Campaign_term__c'].'</li>
		</ul>
		';
		
		if(strpos($email['email_subject'], 'landing') != false){
			$subjectString = '[New Lead from landing page] ';
		} else{
			$subjectString = '[New Lead from contact us page] ';
		}
		$sendResult	= wp_mail($email['email_to'], $subjectString . $email['company'] . ' [' . strtoupper($lang).']', $message);
		if($sendResult) { update_field('lead_record_email', 'on', $lid);  }
		
		
		/*************************
		 ** SEND EMAIL TO SALESFORCE
		 **************************/
		
		// REMOVE TEXT AFTER DOTS ":" IN PRODUCT NAME
		$tmpProductNames 	= explode(',', $email['som']);
		$email['som'] = '';
		
		foreach($tmpProductNames as $tmpProdNm) {
			$tmp			= explode(':', $tmpProdNm);
			$email['som'] 	.= $tmp[0].',';
		}
		rtrim($email['som'], ',');
		
		
		// BUILD FIELD FOR CURL URL
//		$fieldURL 	= array();
		
		// CONNECTION STUFF
		$sfdc_data = array(
			'FirstName' => htmlspecialchars($email['first_name']),
			'LastName' => htmlspecialchars($email['last_name']),
			'Company' => htmlspecialchars($email['company']),
			'Email' => htmlspecialchars($email['email']),
			'Country' => ucwords( str_replace('-', ' ', htmlspecialchars($email['country']) )),
			'Phone' => htmlspecialchars($email['phone']),
			'Note__c' => htmlspecialchars($email['note']),
			'System__c' => htmlspecialchars($email['System__c']),
			'Operating_System__c' => htmlspecialchars($email['Operating_System__c']),
			'Projected_Quantities__c' => htmlspecialchars($email['Projected_Quantities__c']),
			'LeadSource' => htmlspecialchars($email['lead_source']),
			'Campaign_medium__c' => htmlspecialchars($email['Campaign_medium__c']),
			'Campaign_source__c' => htmlspecialchars($email['Campaign_source__c']),
			'Campaign_content__c' => htmlspecialchars($email['Campaign_content__c']),
			'Campaign_term__c' => htmlspecialchars($email['Campaign_term__c'])
		);
		
		if($email['agreement']) {
			$sfdc_data['Privacy_Policy__c'] = $email['agreement'];
		}

//		$fieldURL[] = 'oid=00D24000000I9Kc';
//		$fieldURL[]	= 'Name='.$email['first_name'].' '.$email['last_name'];
//		$fieldURL[]	= 'first_name='.$email['first_name'];
//		$fieldURL[]	= 'last_name='.$email['last_name'];
//		$fieldURL[]	= 'company='.$email['company'];
//		$fieldURL[]	= 'email='.$email['email'];
//		$fieldURL[]	= 'country='.ucwords( str_replace('-', ' ', $email['country']) );
//		$fieldURL[]	= 'phone='.$email['phone'];
//		$fieldURL[]	= 'Note__c='.$email['note'];
//		$fieldURL[]	= 'System__c='.$email['System__c'];
//		$fieldURL[]	= 'Operating_System__c='.$email['Operating_System__c'];
//		$fieldURL[]	= 'Projected_Quantities__c='.$email['Projected_Quantities__c'];
//		$fieldURL[]	= 'lead_source='.$email['lead_source'];
//		$fieldURL[]	= 'Campaign_medium__c='.$email['Campaign_medium__c'];
//		$fieldURL[]	= 'Campaign_source__c='.$email['Campaign_source__c'];
//		$fieldURL[]	= 'Campaign_content__c='.$email['Campaign_content__c'];
//		$fieldURL[]	= 'Campaign_term__c='.$email['Campaign_term__c'];
//      $fieldURL[]	= 'Terms_Conditions__c='.$email['agreement'];
//      $fieldURL[]	= 'retURL='.$email['thanks'];
		
		// Connect to the SFDC SOAP API to pass the lead data
        if(! class_exists('SforceSoapClient')) {
            require_once dirname(__DIR__) . '/inc/soapclient/SforcePartnerClient.php';
        }
		
		$sfdc_creds = array(
			'user' => 'hadas.s@variscite.com',
			'password' => 'Sh102030',
			'token' => 'FZH6Hm8zOGtOVYa2UADxLF73t'
		);
		
		$sfdc_wsdl = dirname(__DIR__) . '/inc/soapclient/partner.wsdl.xml';
		
		$SFDC = new SforcePartnerClient();
		$SFDC->createConnection($sfdc_wsdl);
		$SFDC->login($sfdc_creds['user'], $sfdc_creds['password'] . $sfdc_creds['token']);
		
		// Init the connection to the API
		try {
			$records = array();
			
			$records[0] = new SObject();
			$records[0]->type = 'Lead';
			$records[0]->fields = $sfdc_data;
			
			$response = $SFDC->create($records);
			
			if($response[0]->success == true){
				update_field('lead_record_sf', 'on', $lid);
			} else {
				update_field('curl_errors_documentation', 'Request failed: HTTP status code: ' . json_encode($response), $lid);
			}
			
		} catch (SoapFault $e) {
			
			# Catch and send out email to support if there is an error
			$errmessage =  "Exception ".$e->faultstring."<br/><br/>\n";
			$errmessage .= "Last Request:<br/><br/>\n";
			$errmessage .= $SFDC->getLastRequestHeaders();
			$errmessage .= "<br/><br/>\n";
			$errmessage .= $SFDC->getLastRequest();
			$errmessage .= "<br/><br/>\n";
			$errmessage .= "Last Response:<br/><br/>\n";
			$errmessage .= $SFDC->getLastResponseHeaders();
			$errmessage .= "<br/><br/>\n";
			$errmessage .= $SFDC->getLastResponse();
			
			update_field('curl_errors_documentation', json_encode($errmessage), $lid);
			sfalert_email($lid);
			
		} catch (Exception $e) {
			
			# Catch and send out email to support if there is an error
			$errmessage =  "Exception ".$e->faultstring."<br/><br/>\n";
			$errmessage .= "Last Request:<br/><br/>\n";
			$errmessage .= $SFDC->getLastRequestHeaders();
			$errmessage .= "<br/><br/>\n";
			$errmessage .= $SFDC->getLastRequest();
			$errmessage .= "<br/><br/>\n";
			$errmessage .= "Last Response:<br/><br/>\n";
			$errmessage .= $SFDC->getLastResponseHeaders();
			$errmessage .= "<br/><br/>\n";
			$errmessage .= $SFDC->getLastResponse();
			
			update_field('curl_errors_documentation', json_encode($errmessage), $lid);
			sfalert_email($lid);
		}
		
		// RUN CURL
//		$email_string 	= implode ('&', $fieldURL);
//		$ch 			= curl_init();


//		$con_url = 'https://webto.salesforce.com/servlet/servlet.WebToLead?encoding=UTF-8';
//		curl_setopt($ch, CURLOPT_URL, $con_url);
//		curl_setopt($ch, CURLOPT_POST, 1);														// Set the method to POST
//		curl_setopt($ch, CURLOPT_POSTFIELDS, $email_string);									// Pass POST data
//		curl_exec($ch); 																		// Post to Salesforce
		
		
		// RECORD ERRORS OR MARK SENT IN LEAD
//		if (curl_errno($ch)) {
//			update_field('curl_errors_documentation', curl_error($ch), $lid);
//			sfalert_email($lid);
//		}
//		else {
//			$resultStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
//			if ($resultStatus == 200) { update_field('lead_record_sf', 'on', $lid); }
//			else { update_field('curl_errors_documentation', 'Request failed: HTTP status code: ' . $resultStatus, $lid); }
//		}
		
		// BUILD RESPONSE
		$resData = array(
			'thanks' => $email['thanks'],
		);
		
		wp_send_json_success($resData);
		
		curl_close($ch);
	}
	
	wp_die();
}
?>