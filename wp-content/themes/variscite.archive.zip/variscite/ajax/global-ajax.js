jQuery(function($){


	/*********************************************
	** AJAX LOAD MORE POSTS
	********************************************
	$("#postsLoadMore").click(function () {

		$(this).find('.loading').fadeIn();

		$.post(ajax_object.ajaxurl, {
			action: "global_ajaxfunc",
			action_type: "posts_loadmore",
			count: $(this).attr("data-count"),
			cats: $(this).attr("data-ccat"),
			tag: $(this).attr("data-tag"),
			author: $(this).attr("data-author"),
		}, function(res) {
			var success	= res.success;
			var posts 	= res.data.posts;
			var count 	= res.data.count;
			var msg 	= res.data.msg;

			$("#postsLoadMore").find('.loading').fadeOut();

			if(success) {
				$('#posts-box').append(posts);
				$('#postsLoadMore').attr('data-count', count);
			}
			else if ( ! res.success ) {
				$("#postsLoadMore").remove();
				$(".nomoreposts").fadeIn();
			}

		});

	});
	*/



	/*************************************************
	** HANDLE SPECS PAGE FORM SUBMISSION
	*************************************************/

	function sgActivateTab(tabid) {
		$('.quote-tabs a').each(function() { $(this).parent().removeClass('active'); })
		$('.quote-form .tab-content .tab-pane').each(function() { $(this).removeClass('active'); })

		$('.quote-tabs a[href="'+tabid+'"]').parent().addClass('active');
		$('.quote-form .tab-content').find(tabid).addClass('active');
	}

	$('.goToFirstTab, a[href="#pspec"]').click(function() { sgActivateTab('#pspec'); });


	function checkQuoteFormStepOne() {
		var somVals 	= [];
		var sysVals 	= [];
		var amntVals 	= [];

		$.each($("input[name='quote-product']:checked"), function() { somVals.push($(this).val()); });		// COLLECT SELECTED SOMS CHECKBOXES
		$.each($(".opsysBtns button.active"), function() { sysVals.push($(this).val()); });					// COLLECT SELECTED OPERATING SYSTEMS BUTTONS
		$.each($("input[name='quote-quantity']:checked"), function() { amntVals.push($(this).val()); });	// COLLECT SELECTED OPERATING SYSTEMS BUTTONS

		if( somVals.length > 0 && sysVals.length > 0 && amntVals.length > 0){ return true }
		else {return false}
	}

    function validateEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
	function checkQuoteFormStepTwo() {

		check = '';

		$('.pinfo-form').find('input[type="text"]').each(function() {

			if( $(this).val().length < 1 ) {
				check = true;
				return false;
			}
		});

		if( $('#country_code').find(":selected").val().length < 1 ) {check = true};

        var emailVal = $('#email').val();
        if(! validateEmail(emailVal) ) {check = true};

		return check;
	}
	var fields_warn = document.documentElement.lang == "de-DE" ? "Bitte alle Felder ausfüllen" : "All Fields Are Required";

	$('.quote-form .goToSecondTab, .quote-form a[aria-controls="pinfo"]').click(function(e) {
		e.preventDefault();
		$('.quote-form .notice').html('');
		var checks = checkQuoteFormStepOne();

		if(checks) { sgActivateTab('#pinfo'); }
		else { $('.quote-form #pspec .notice').html('<i class="fa fa-exclamation-triangle c6"></i> ' + fields_warn); return false; }
	});



	// COLLECT ALL FORM DATA INTO ARRAY
	function collect_quoteform_info() {
		var formdata = {'som' : [], 'sys' : [], 'amount' : [], 'userinfo' : []};
		$.each($(".quote-form input[name='quote-product']:checked"), function() { formdata['som'].push($(this).val()); });									// COLLECT SELECTED SOMS CHECKBOXES
		$.each($(".quote-form .opsysBtns button.active"), function() { formdata['sys'].push( $(this).attr('data-value') ); });								// COLLECT SELECTED OPERATING SYSTEMS BUTTONS
		formdata['amount'].push( $(".quote-form input[name='quote-quantity']:checked").val());																// COLLECT SELECTED QUANTITY
		$.each($(".quote-form .pinfo-form input[type=\"text\"]"), function() { formdata['userinfo'].push( $(this).attr('id') + ':' + $(this).val() ); });	// COLLECT USER INFO

		if($(".quote-form input[name='agreement']:checked").length > 0) {
            formdata['userinfo'].push( 'agreement:' + $(".quote-form input[name='agreement']:checked").val());																// COLLECT Privacy Policy field
        }
        formdata['userinfo'].push( 'email:' + $('#email').val() );
		formdata['userinfo'].push( 'country:' + $('#country_code').find(":selected").val() );
		formdata['userinfo'].push( 'note:' + $('#note').val() );
		formdata['userinfo'].push( 'url:' + $('#curl').val() );
		formdata['userinfo'].push( 'device:' + $('#cdevice').val() );
		formdata['userinfo'].push( 'Campaign_medium__c:' + $('#Campaign_medium__c').val() );
		formdata['userinfo'].push( 'Campaign_source__c:' + $('#Campaign_source__c').val() );
		formdata['userinfo'].push( 'Campaign_content__c:' + $('#Campaign_content__c').val() );
		formdata['userinfo'].push( 'Campaign_term__c:' + $('#Campaign_term__c').val() );
		formdata['userinfo'].push( 'leadsource:' + $('#leadsource').val() );
		formdata['userinfo'].push( 'thanks:' + $('#thanks').val() );

		return formdata;
	}



	// SUBMIT FORM
	$('.submitQuoteRequest').click(function() {
		$('.quote-form .notice').html('');

		notice = '.quote-form #pinfo .notice';
		checks = checkQuoteFormStepTwo();

		if(checks) { $(notice).html('<i class="fa fa-exclamation-triangle c6"></i> ' + fields_warn); return false; }
		else if( !$('#first_name').val() ) { $(notice).html('<i class="fa fa-exclamation-triangle c6"></i> Enter full name'); return false; }
		// else if( !$('#captachResponse').val() ) { $(notice).html('<i class="fa fa-microchip c3"></i> You forgot the captcha'); return false; }
		else {

			$('.submitQuoteRequest').attr('disabled', 'disabled');
			$('.submitQuoteRequest').parent().toggleClass('btnLoader');

			// SEND FORM
			$.post(ajax_object.ajaxurl, {
				action: 'global_ajaxfunc',
				action_type: 'send_quote',
				form_data: collect_quoteform_info(),
			}, function(res) {

				$('.submitQuoteRequest').attr('disabled', false);
				$('.submitQuoteRequest').parent().toggleClass('btnLoader');

				if(res.success) {
					dataLayer.push({'event': 'form-mainSite-getAQuote-success'});
					window.location.href = res.data.thanks;
				}
				else {
					$('.quote-form .notice').html( '<i class="fa fa-exclamation-triangle c6"></i> ' + res.data.msg );
				}

			});

		}

	});


	// VALUE BY FIELD TYPE


	// SUBMIT FORM
	$('.submitQuoteWidgetRequest').click(function() {

        $('.submitQuoteWidgetRequest').attr('disabled', 'disabled');
        $('.submitQuoteWidgetRequest').parent().toggleClass('btnLoader');

        // COLLECT VALUES
		var form 	= document.getElementById("quoteFormWidget");
		var iEle 	= form.querySelectorAll("input, select, checkbox, textarea");
		var notice	= '#quoteFormWidget .notice';
		var checks 	= false;

		var fldVals = {};

		$.each(iEle, function( index, value ) {
			fldType 	= iEle[index].type;

			if(fldType == 'hidden' || fldType == 'text' || fldType == 'textarea') {
				fldVals[iEle[index].id] = iEle[index].value;
			}
			else if(fldType == 'select-one') {
				fldVals[iEle[index].id] = $('#' + iEle[index].id).val();
			}
			else if(fldType == 'checkbox') {
				if ($('#' + iEle[index].id).is(':checked')) {
					if(!fldVals[iEle[index].name]) {fldVals[iEle[index].name] = '';}
					fldVals[iEle[index].name] += $('#' + iEle[index].id).val() + ',';
				}
			}
		});


		// console.log(fldVals);

		// CHECK IF REQUIRED ARE FIELD
		var checks					= false;
		var completereqFields 		= fldVals.required.split(',');
		var reqFields 				= fldVals.required.split(',');

        fieldMessage = '';
		$(reqFields).each(function(index, value) {
			if(value === 'email'){
                var emailVal = $('#email').val();
                if(! validateEmail(emailVal) ) {
                    checks = true;
                    inputid = value;
                    fieldMessage = 'A Valid Email';
                    return false;
                }
			}
			if( !fldVals[value] ) {
				checks = true;
				inputid = value;
				return false;
			}
		});



		if(checks === true) {
			$(notice).html('<i class="fa fa-exclamation-triangle c6"></i> '+ $('label[for="'+inputid+'"]').text() + fieldMessage + ' is Required');

            $('.submitQuoteWidgetRequest').attr('disabled', false);
            $('.submitQuoteWidgetRequest').parent().toggleClass('btnLoader');

            return false;
		}
		// else if( !$('#captachResponse').val() ) { $(notice).html('<i class="fa fa-microchip c3"></i> You forgot the captcha'); return false; }
		else {
			// SEND FORM
			$.post(ajax_object.ajaxurl, {
				action: 'global_ajaxfunc',
				action_type: 'send_widget_quote',
				form_data: fldVals,
			}, function(res) {

                $('.submitQuoteWidgetRequest').attr('disabled', false);
                $('.submitQuoteWidgetRequest').parent().toggleClass('btnLoader');

				if(res.success) {
                    var event_name 				=  $(form).find('#event_name').val();

                    if(event_name) {
                        dataLayer.push({'event': event_name});
                    }

                    var thanksPageUrl 		= $('.quote-form').find('#thanks').val();
					window.location.href 	= thanksPageUrl;

				}
				else {
					$('.quote-form .notice').html( '<i class="fa fa-exclamation-triangle c6"></i> ' + res.data.msg );
				}

			});

		}


	});

});




